<?php

?>
<div class="reveal" id="loginForm" data-reveal>
	<form class="log-in-form">
		<h4 class="text-center">LOG IND</h4>
		<label><input type="email" placeholder="EMAIL"></label>
		<label><input type="password" placeholder="ADGANGSKODE"></label>
		<p><input type="submit" class="button expanded color-bg-primary" value="&rarr;"></input></p>
	</form>
	<button class="close-button" data-close aria-label="Close modal" type="button">
	<span aria-hidden="true">&times;</span>
	</button>
</div>