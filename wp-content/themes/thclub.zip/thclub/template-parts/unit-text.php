<?php
$cw = get_sub_field('text_txt_cw');

$t = get_sub_field('text_txt_t');
$title = get_sub_field('text_txt_title');
$element = get_sub_field('text_txt_element');
$ct = get_sub_field('text_txt_ct');

if ($cw) {
  $w = get_sub_field('text_txt_w');
  $wc = new WrapperClass($w, ''); 
}

$tc = new TypographyClass($t, $title, $ct, $element, '', '');
$bc = new ButtonClass(get_sub_field('text_txt_button'), 'a');
$pc = new PhotoClass(get_sub_field('text_txt_bg_image'));
?>
<div class="text-area <?= ($cw) ? $wc->marginPadding() : ''?>" <?= ($cw) ? $wc->wrapperStyle() : '' ?>>
  <div class="grid-container <?= ($cw) ? $wc->wrapperSize() : '' ?>">
    <div class="wow slideInUp cell small-12">
      <?= ($pc->imgurl()) ? '<div class="lazy cover txt-bg-image" data-src="<?= $pc->imgurl() ?>"></div>' : '' ?>
      <div class="text">
        <?= $tc->title() ?>
        <div class="medium-top-margin medium-bottom-margin"><?= get_sub_field('text_txt_text') ?></div>
        <?= $bc->buttonSingle() ?>
      </div>
    </div>
  </div>
</div>