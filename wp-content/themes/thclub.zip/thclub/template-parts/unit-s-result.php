<?php
$cw = get_sub_field('sr_cw');
if ($cw) {
  $w = get_sub_field('sr_w');
  $wc = new WrapperClass($w, ''); 
}
?>

<div class="sr-area <?= ($cw) ? $wc->marginPadding() : ''?>" <?= ($cw) ? $wc->wrapperStyle() : '' ?>>
	<div class="grid-container <?= ($cw) ? $wc->wrapperSize() : '' ?>">
		<div id="s-result" class="grid-x grid-padding-x small-up-2 medium-up-3 large-up-3 align-center">
			
		<div class="cell wow slideInUp high-bottom-margin" data-wow-delay="150ms">
			<div class="drop-shadow lazy cover tg-bg-image" style="height: 286.151px; background-image: url(<?= get_template_directory_uri()?>/dist/assets/images/products/p1.jpg "></div>
			<div class="p-info clearfix">
				<a class="p-name font-condensed font-18 float-left color-text-darkgray">FRI LEVERING PÅ MATERIALER BYGMA</a>
				<a class="p-price font-condensed font-15 float-right text-center color-bg-primary color-text-white">0 <br/>POINTS</a>
			</div>
			<a class="p-link font-condensed font-18 color-text-gray">&rarr; <u>LÆS MERE</u></a><hr/>
		</div>
		<div class="cell wow slideInUp high-bottom-margin" data-wow-delay="300ms">
			<div class="drop-shadow lazy cover tg-bg-image" style="height: 286.151px; background-image: url(<?= get_template_directory_uri()?>/dist/assets/images/products/p2.jpg "></div>
			<div class="p-info clearfix">
				<a class="p-name font-condensed font-18 float-left color-text-darkgray">SPAR 2500,- I OPRETTELSESGEBYR SPAREKASSEN KRONJYLLAND</a>
				<a class="p-price font-condensed font-15 float-right text-center color-bg-primary color-text-white">0 <br/>POINTS</a>
			</div>
			<a class="p-link font-condensed font-18 color-text-gray">&rarr; <u>LÆS MERE</u></a><hr/>
		</div>
		<div class="cell wow slideInUp high-bottom-margin" data-wow-delay="450ms">
			<div class="drop-shadow lazy cover tg-bg-image" style="height: 286.151px; background-image: url(<?= get_template_directory_uri()?>/dist/assets/images/products/p3.jpg "></div>
			<div class="p-info clearfix">
				<a class="p-name font-condensed font-18 float-left color-text-darkgray">FÅ 3 FOR 1 - UDVALGTE VARER HUMMEL</a>
				<a class="p-price font-condensed font-15 float-right text-center color-bg-primary color-text-white">0 <br/>POINTS</a>
			</div>
			<a class="p-link font-condensed font-18 color-text-gray">&rarr; <u>LÆS MERE</u></a><hr/>
		</div>
		<div class="cell wow slideInUp high-bottom-margin" data-wow-delay="150ms">
			<div class="drop-shadow lazy cover tg-bg-image" style="height: 286.151px; background-image: url(<?= get_template_directory_uri()?>/dist/assets/images/products/p4.jpg "></div>
			<div class="p-info clearfix">
				<a class="p-name font-condensed font-18 float-left color-text-darkgray">FÅ 3 FOR 1 - UDVALGTE VARER HUMMEL</a>
				<a class="p-price font-condensed font-15 font-18 float-right text-center color-bg-primary color-text-white">0 <br/>POINTS</a>
			</div>
			<a class="p-link font-condensed font-18 color-text-gray">&rarr; <u>LÆS MERE</u></a><hr/>
		</div>
		<div class="cell wow slideInUp high-bottom-margin" data-wow-delay="300ms">
			<div class="drop-shadow lazy cover tg-bg-image" style="height: 286.151px; background-image: url(<?= get_template_directory_uri()?>/dist/assets/images/products/p5.jpg "></div>
			<div class="p-info clearfix">
				<a class="p-name font-condensed font-18 float-left color-text-darkgray">FÅ 3 FOR 1 - UDVALGTE VARER HUMMEL</a>
				<a class="p-price font-condensed font-15 float-right text-center color-bg-primary color-text-white">0 <br/>POINTS</a>
			</div>
			<a class="p-link font-condensed font-18 color-text-gray">&rarr; <u>LÆS MERE</u></a><hr/>
		</div>
		<div class="cell wow slideInUp high-bottom-margin" data-wow-delay="450ms">
			<div class="drop-shadow lazy cover tg-bg-image" style="height: 286.151px; background-image: url(<?= get_template_directory_uri()?>/dist/assets/images/products/p6.jpg "></div>
			<div class="p-info clearfix">
				<a class="p-name font-condensed font-18 float-left color-text-darkgray">FÅ 3 FOR 1 - UDVALGTE VARER HUMMEL</a>
				<a class="p-price font-condensed font-15 float-right text-center color-bg-primary color-text-white">0 <br/>POINTS</a>
			</div>
			<a class="p-link font-condensed font-18 color-text-gray">&rarr; <u>LÆS MERE</u></a><hr/>
		</div>
		</div>
	</div>
</div>