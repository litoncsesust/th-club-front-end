<?php
add_filter( 'wp_nav_menu_items', 'fiftytwo_loginout_menu_link', 10, 2 );

function fiftytwo_loginout_menu_link( $items, $args ) {
  if ($args->theme_location == 'top-bar-r' || $args->theme_location == 'mobile-nav' ) {
    if (is_user_logged_in()) {
      $items .= '<li class="right color-bg-primary"><a class="color-text-white outline" href="'. wp_logout_url() .'">'. __("Log Ud") .'</a></li>';
    } else {
      $items .= '<li class="right color-bg-primary"><a class="color-text-white outline" data-open="loginForm">'. __("Log ind") .'</a></li>';
    }
  }
  return $items;
}