<?php
/**
 * Author: Ole Fredrik Lie
 * URL: http://olefredrik.com
 *
 * fiftytwo functions and definitions
 *
 * Set up the theme and provides some helper functions, which are used in the
 * theme as custom template tags. Others are attached to action and filter
 * hooks in WordPress to change core functionality.
 *
 * @link https://codex.wordpress.org/Theme_Development
 * @package fiftytwo
 * @since fiftytwo 1.0.0
 */

/** Various clean up functions */
require_once( 'library/login.php' );
require_once( 'library/login-nav.php' );
require_once( 'library/cleanup.php' );
require_once( 'library/foundation.php' );
require_once( 'library/class-fiftytwo-comments.php' );
require_once( 'library/navigation.php' );
require_once( 'library/class-fiftytwo-top-bar-walker.php' );
require_once( 'library/class-fiftytwo-mobile-walker.php' );
require_once( 'library/widget-areas.php' );
require_once( 'library/entry-meta.php' );
require_once( 'library/enqueue-scripts.php' );
require_once( 'library/theme-support.php' );
require_once( 'library/custom-nav.php' );
require_once( 'library/sticky-posts.php' );
require_once( 'library/responsive-images.php' );
require_once( 'library/gutenberg.php' );

require_once('library/class-ButtonClass.php');
require_once('library/class-PhotoClass.php');
require_once('library/class-TypographyClass.php');
require_once('library/class-WrapperClass.php');

/** If your site requires protocol relative url's for theme assets, uncomment the line below */
// require_once( 'library/class-fiftytwo-protocol-relative-theme-assets.php' );
