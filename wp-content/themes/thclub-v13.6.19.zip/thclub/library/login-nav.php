<?php
add_filter( 'wp_nav_menu_items', 'fiftytwo_loginout_menu_link', 10, 2 );

function fiftytwo_loginout_menu_link( $items, $args ) {
  if ($args->theme_location == 'top-bar-r' || $args->theme_location == 'mobile-nav' ) {
    if (isset($_SESSION['clubKey'])) {
      $items .= '<li class="right color-bg-primary"><a class="color-text-white outline" href="'. site_url() .'/logout">'. __("Log Ud") .'</a></li>';
    } else {
      $items .= '<li class="right color-bg-primary"><a class="color-text-white outline" data-open="loginForm">'. __("Log ind") .'</a></li>';
    }
  }
  return $items;
}