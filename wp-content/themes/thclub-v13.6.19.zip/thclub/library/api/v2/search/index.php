<?php
include dirname(dirname(__FILE__)) . '/vendor/autoload.php';
use Nahid\JsonQ\Jsonq;
 
class SearchClass {
  protected $leasing;

  public function __construct($leasing) {
    $this->leasing = $leasing;
  }

	public function search() {
		$q = new Jsonq(dirname(dirname(__FILE__)) . '/data/cars.json');
		try {
			$Make = (isset($_GET['Make'])) ? $_GET['Make'] : false;
			$Type = (isset($_GET['Type'])) ? $_GET['Type'] : false;
			$Fuel = (isset($_GET['Fuel'])) ? $_GET['Fuel'] : false;
			$min = (isset($_GET['min'])) ? $_GET['min'] : 0;
			$max = (isset($_GET['max'])) ? $_GET['max'] : 0;		
			$min = $this->removeDot($min);
			$max = $this->removeDot($max);



			$Make_op = ($Make && (strcmp($Make, 'all') !== 0)) ? '==' : '!=='; 
			$Type_op = ($Type && (strcmp($Type, 'all') !== 0)) ? '==' : '!=='; 
			$Fuel_op = ($Fuel && (strcmp($Fuel, 'all') !== 0)) ? '==' : '!=='; 
			$min_op = ($min) ? '>=' : '!=='; 
			$max_op = ($max) ? '<=' : '!=='; 


			$res = $q->where('FabrikatNavn', $Make_op, $Make)
			->where('TypeNavn', $Type_op, $Type)
			->where('FuelType', $Fuel_op, $Fuel)
			->where('carPrice', $min_op, $min)
			->where('carPrice', $max_op, $max)
			->get();

			return attributes($res, $this->leasing);
		} catch (\Nahid\JsonQ\Exceptions\ConditionNotAllowedException $e) {
			return $e->getMessage();
		} catch (\Nahid\JsonQ\Exceptions\NullValueException $e) {
			return $e->getMessage();
		}
	}

	private function removeDot($normal) {
    return str_replace(".", "", $normal);
	}  
}