<?php
include dirname(dirname(__FILE__)) . '/vendor/autoload.php';
use Nahid\JsonQ\Jsonq;
header('Content-Type: application/json');

class SearchClass {
	public function search() {
	$q = new Jsonq(dirname(dirname(__FILE__)) . '/data/cars.json');

	try {
		$Make = (isset($_GET['Make'])) ? $_GET['Make'] : false;
		$Type = (isset($_GET['Type'])) ? $_GET['Type'] : false;
		$Fuel = (isset($_GET['Fuel'])) ? $_GET['Fuel'] : false;
		
		$Make_op = ($Make) ? '==' : '!=='; 
		$Type_op = ($Type) ? '==' : '!=='; 
		$Fuel_op = ($Fuel) ? '==' : '!=='; 
		
		$res = $q->from('Vehicles')
		->where('Make',$Make_op, $Make)
		->where('Type',$Type_op, $Type)
		->where('Propellant',$Fuel_op, $Fuel)
		->get();
		
		$return[] = array();
		$i = 0;
		foreach ($res as $car) {
      echo 'LeasingPrice: ' . $car->LeasingPrice;
      if ($car->LeasingPrice):
			$return[$i]['LeasingPrice'] = $car->LeasingPrice;
            $return[$i]['id'] = $car->Id;
			$return[$i]['image'] = $car->Pictures[0];
			$return[$i]['name'] = $car->Make . ' ' . $car->Model . ' ' .  $car->Motor . '' . $car->Variant;
			$return[$i]['category'] = $car->LeasingPrice ? 'Leasing' : 'Personbil';
			$return[$i]['year'] = $car->Year;
			$return[$i]['mileage'] = $car->Mileage;
			$return[$i]['propellant'] = $car->Propellant;
			$return[$i]['condition'] = $car->Condition;
			$return[$i]['kmpl'] = $car->KmPerLiter;
			$return[$i]['city'] = $car->DealerAddressCity;
			$price = str_replace(",", ".", number_format($car->NewPrice));
			$return[$i]['price'] = ($price) ?  $price . ' DKK' : 'Læs mere';
          endif;
			$i++;
		}
		return $return;
	} catch (\Nahid\JsonQ\Exceptions\ConditionNotAllowedException $e) {
		return $e->getMessage();
	} catch (\Nahid\JsonQ\Exceptions\NullValueException $e) {
		return $e->getMessage();
	}
	}  
}