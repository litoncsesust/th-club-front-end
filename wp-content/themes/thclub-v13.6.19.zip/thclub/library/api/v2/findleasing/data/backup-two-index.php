
<?php

class LeasingCarListingClass {

	private $token = 'Token 12f3e8a6873ed33f63d0171e0198f6df6eae5aeb';
  private $offers_api_url = 'https://www.findleasing.nu/api/offers/?show_in_iframe=true';
  private $leasing_api_url = 'https://www.findleasing.nu/api/car-listings/';

  private function args() {
		return array('headers' => array('Content-type' => 'application/json', 'Authorization' => $this->token));
	}

	public function leasingCarListing() {
		$leasing_response = wp_remote_get( $this->leasing_api_url, $this->args() );
		$offers_response = wp_remote_get( $this->offers_api_url, $this->args() );
		// Is the API up?
		if ( ! 200 == wp_remote_retrieve_response_code( $leasing_response ) ) {
			return false;
		}
		if ( ! 200 == wp_remote_retrieve_response_code( $offers_response ) ) {
			return false;
		}

		$leasing_data = wp_remote_retrieve_body( $leasing_response );
		$leasing_data = json_decode($leasing_data, true);

		$offers_data = wp_remote_retrieve_body( $offers_response );
		$offers_data = json_decode($offers_data, true);
		$offers_res = [];
	
		
		foreach ($offers_data['results'] as $key => $val) {
			$offers_res[$val['title']] = $val;
		}
		
		foreach ($leasing_data as $key => $val) {  
			/*=============== Offer API data integration=======================*/
			if (array_key_exists($val['header'], $offers_res)) {				
				$leasing_data[$key]['dataid'] = $offers_res[$val['header']]['id'];
				$leasing_data[$key]['efficiency'] = $offers_res[$val['header']]['car']['efficiency'];
			}
			/*=============== Offer API data integration=======================*/
			$leasing_data[$key]['FuelType'] = $this->addFuelType($val);
			$leasing_data[$key]['LeasingType'] = $this->addLeasingType($val);
		}

		$lcf = fopen(dirname(dirname(__FILE__)) . '/data/leasingcars.json', 'w');
		fwrite($lcf, json_encode($leasing_data, true));
		fclose($lcf);
	}

	private function getOfferData(){
		$page_offer_data = [];
		for ($i=1; $i <=500 ; $i++) { 
			$offers_api_url = $this->offers_api_url . '?page='.$i;
			if(wp_remote_get( $offers_api_url, $this->args() )['response']['code'] == 404){
				break;
			}
			$offers_response = wp_remote_get( $offers_api_url, $this->args() );
			$offers_data = wp_remote_retrieve_body( $offers_response );
			$offers_data = json_decode($offers_data, true);
			$page_offer_data = array_merge($page_offer_data, $offers_data['results']);
		}
		
		$offers_res = [];
		$i=0;
		foreach ($page_offer_data as $key => $val) {
			$offers_res[$i] = $val;
			$i++;
		}

		return $offers_res;
	}

	public function offerCarListing() {
		$offers_response = wp_remote_get( $this->offers_api_url, $this->args() );
		// Is the API up?
		if ( ! 200 == wp_remote_retrieve_response_code( $offers_response ) ) {
			return false;
		}

		$offers_data = wp_remote_retrieve_body( $offers_response );
		$offers_res = json_decode($offers_data, true);

		if ($offers_res['links']['next']) { 
			$offers_res = $this->getOfferData();
		}

		foreach ($offers_res['results'] as $key => $val) {  
			$offers_res['results'][$key]['car_make'] = $this->addCM($val);
			$offers_res['results'][$key]['fuel_type'] = $this->addFT($val);
			$offers_res['results'][$key]['leasing'] = $this->addLT($val);
			$offers_res['results'][$key]['page_id'] = $this->addPageID($val);
		}

		$ocf = fopen(dirname(dirname(__FILE__)) . '/data/offercars.json', 'w');
		fwrite($ocf, json_encode($offers_res['results'], true));
		fclose($ocf);
	}

	private function addCM($data = null) {
		return $data['car']['make'];
	}
	private function addFT($data = null) {
		return $data['car']['fuel_type'];
	}
	private function addLT($data = null) {
		return $data['leasing_type']['text'];
	}

	private function addPageID($data = null) {
		$id = str_split($data['id']);
		$wordtonumber = [];
		$i=0;
		foreach ($id as $key => $val) {
		  $wordtonumber[$i] = is_numeric($val) ? $val : $this->toNumber($val) ;
		  $i++;
		}
		return implode($wordtonumber);
	}


	private function toNumber($dest) {
	  if ($dest) {
	    return ord(strtolower($dest)) - 96;
	  } else {
	    return 0;
	  }
	}

	private function addFuelType($data = null) {
		return ($data['fuel_type'] == '0') ? 'Benzin' : (($data['fuel_type'] == '1') ? 'Diesel' : 'EL');
	}

	private function addLeasingType($data = null) {
		return ($data['leasing_type'] == '0') ? 'Flexleasing' : (($data['leasing_type'] == '2') ? 'Leasing' : '');
	}
}