<?php
include get_template_directory() . '/library/api/v2/vendor/autoload.php';
use Nahid\JsonQ\Jsonq;
 
class LeasingSearchClass {
	public function leasingSearch() {
		$q = new Jsonq(dirname(dirname(__FILE__)) . '/data/leasingcars.json');

		try {
			$Make = (isset($_GET['Make'])) ? $_GET['Make'] : false;
			$Type = (isset($_GET['Type'])) ? $_GET['Type'] : false;
			$Fuel = (isset($_GET['Fuel'])) ? $_GET['Fuel'] : false;
			//$min = (isset($_GET['min'])) ? $_GET['min'] : 0;
			//$max = (isset($_GET['max'])) ? $_GET['max'] : 0;
			
			if ($Make && (!$Type) && (!$Fuel)) {
				$res = $q->where('make_name', $Make)->get();
			} elseif ($Type && (!$Fuel) && (!$Make)) {
				$res = $q->where('LeasingType', $Type)->get();
			} elseif ($Fuel && (!$Make) && (!$Type)) {
				$res = $q->where('FuelType', $Fuel)->get();
			} elseif ($Make && $Type && (!$Fuel)) {
				$res = $q->where('make_name', $Make)->where('LeasingType', $Type)->get();
			} elseif ($Type && $Fuel && (!$Make)) {
				$res = $q->where('LeasingType', $Type)->where('FuelType', $Fuel)->get();
			} elseif ($Fuel && $Make && (!$Type)) {
				$res = $q->where('make_name', $Make)->where('FuelType', $Fuel)->get();
			} else {
				$res = $q->where('make_name', $Make)->where('LeasingType', $Type)->where('FuelType', $Fuel)->get();
			}
			return leasingAttributes($res);
		} catch (\Nahid\JsonQ\Exceptions\ConditionNotAllowedException $e) {
			return $e->getMessage();
		} catch (\Nahid\JsonQ\Exceptions\NullValueException $e) {
			return $e->getMessage();
		}
	}  
}