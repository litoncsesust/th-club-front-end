<?php 
include get_template_directory() . '/library/api/v2/vendor/autoload.php';
use Nahid\JsonQ\Jsonq;

class LeasingCarSliderClass {
	protected $make;

	public function __construct($make) {
		$this->make = $make;
	}

	public function leasingSlider() {
		try {
			$q = new Jsonq(dirname(dirname(__FILE__)) . '/data/leasingcars.json');
			$res = ($this->make) ? $q->where('make_name', $this->make)->get() : $q->get();
			return leasingSliderAttributes($res);
		} catch (\Nahid\JsonQ\Exceptions\ConditionNotAllowedException $e) {
		  return $e->getMessage();
		} catch (\Nahid\JsonQ\Exceptions\NullValueException $e) {
		  return $e->getMessage();
		}
	}
}	

function leasingSliderAttributes($res) {
	$return[] = array();
	$i = 0;
	foreach ($res as $car) {
		$return[$i]['id'] = $car->id;
		$return[$i]['name'] = $car->full_header;
		$return[$i]['image'] = $car->thumbnail_url;
		$LeasingPrice = str_replace(',', '.', number_format($car->total_cost));
		$return[$i]['price'] = ($price) ?  $price . ' DKK' : $LeasingPrice . ' DKK';
		$i++;
	}
	return $return;
}