<?php
include get_template_directory() . '/library/api/v2/vendor/autoload.php';
use Nahid\JsonQ\Jsonq;
 
class BrandArchiveClass {
	protected $make;

  public function __construct($make) {
  	$this->make = $make;
  }

	public function brandArchive() {
		$q = new Jsonq(dirname(dirname(__FILE__)) . '/data/offercars.json');

		try {
			$res = $q->where('car_make', $this->make)->get();
		
			return offersAttributes($res);
		} catch (\Nahid\JsonQ\Exceptions\ConditionNotAllowedException $e) {
			return $e->getMessage();
		} catch (\Nahid\JsonQ\Exceptions\NullValueException $e) {
			return $e->getMessage();
		}
	}  
}