<?php 
include dirname(dirname(__FILE__)) . '/vendor/autoload.php';
use Nahid\JsonQ\Jsonq;

class CarSliderClass {
	protected $make;
    protected $leasing;

	public function __construct($make, $leasing) {
		$this->make = $make;
        $this->leasing = $leasing;
	}

	public function slider() {
		try {
			$q = new Jsonq(dirname(dirname(__FILE__)) . '/data/cars.json');
			$res = ($this->make) ? $q->from('Vehicles')->where('Make', $this->make)->get() : $q->from('Vehicles')->get();
			return slider_attributes($res, $this->leasing);
		} catch (\Nahid\JsonQ\Exceptions\ConditionNotAllowedException $e) {
		  return $e->getMessage();
		} catch (\Nahid\JsonQ\Exceptions\NullValueException $e) {
		  return $e->getMessage();
		}
	}
}	

function slider_attributes($res, $leasing) {
	$return[] = array();
	$i = 0;
	foreach ($res as $car) {
      $oldLeas = ($leasing) ? isset($car->LeasingPrice) : !isset($car->LeasingPrice); 
       if ($oldLeas) {
		$return[$i]['id'] = $car->Id;
		$return[$i]['name'] = $car->Make . ' ' . $car->Model . ' ' .  $car->Motor . '' . $car->Variant;
		$price = str_replace(",", ".", number_format($car->AdvertisedRetailPrice));
        $LeasingPrice = str_replace(",", ".", number_format($car->LeasingPrice));
		$return[$i]['price'] = ($price) ?  $price . ' DKK' : $LeasingPrice . ' DKK/md.';
		$return[$i]['image'] = $car->Pictures[0];
		$i++;
      }
	}
	return $return;
}