<?php 

include '../vendor/autoload.php';
use Nahid\JsonQ\Jsonq;

$q = new Jsonq('../data/cars.json');

try {
	$id = $_GET['Id'];
  $res = $q->from('Vehicles')
			->where('Id', $id)
			->get();
			
	header('Content-Type: application/json');
	echo json_encode($res);
} catch (\Nahid\JsonQ\Exceptions\ConditionNotAllowedException $e) {
    echo $e->getMessage();
} catch (\Nahid\JsonQ\Exceptions\NullValueException $e) {
    echo $e->getMessage();
}