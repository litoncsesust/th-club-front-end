<?php

class CarListingClass {
	public function carListing() {
		$url = "https://services.web.bilinfo.dk/api/vehicle/?user=Matchbiler&password=G2222WpCVX&format=json";
		$data = file_get_contents($url);
		$fp = fopen(dirname(dirname(__FILE__)) . '/data/cars.json', 'w');
		fwrite($fp, $data);
		fclose($fp);
	}
}