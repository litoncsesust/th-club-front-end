<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
  <head>
    <meta http-equiv="content-type" content="text/html; charset=windows-1250">
    <title>PHP Array Pagination</title>
    <style>
    <!--
    body {
    font-family: Tahoma, Verdana, Arial, Sans-serif;
    font-size: 11px;
    }
    hr {
    border: 1px #ccc;
    border-style: none none solid none;
    margin: 20px 0;
    }
    a {
    color: #333;
    text-decoration: none;
    }
    a:hover {
    text-decoration: underline;
    }
    a.selected {
    font-weight: bold;
    text-decoration: underline;
    }
    .numbers {
    line-height: 20px;
    word-spacing: 4px;
    }
    //-->
    </style>
  </head>
  <body>
    <?php
    ini_set('display_errors','On');
    error_reporting(E_ALL);
    include '../vendor/autoload.php';
    use Nahid\JsonQ\Jsonq;
    $q = new Jsonq('../data/cars.json');
    $res = (array)($q->from('Vehicles')->get());
    include 'pagination.class.php';
    if (count($res)) {
    $pagination = new pagination($res, (isset($_GET['page']) ? $_GET['page'] : 1), 15);
    $pagination->setShowFirstAndLast(false);
    $pagination->setMainSeperator(' | ');
    $cars = $pagination->getResults();
      if (count($cars) != 0) {
        $i = 0;
        foreach ($cars as $car) {
          echo $car->Make . ' ' . $car->Model . ' ' . $car->Motor . ' ' . $car->Variant . '<br/>';

          $i++;
        }
        echo $pageNumbers = '<div class="numbers">'.$pagination->getLinks($_GET).'</div>';
      }
    }
    ?>
  </table>
  <hr />
</body>
</html>