<?php
$cw = get_sub_field('sf_cw');
if ($cw) {
  $w = get_sub_field('sf_w');
  $wc = new WrapperClass($w, ''); 
}
?>
<div class="sf-area <?= ($cw) ? $wc->marginPadding() : ''?>" <?= ($cw) ? $wc->wrapperStyle() : '' ?>>
	<form action="<?= get_the_permalink() ?>" method="post" class="grid-container <?= ($cw) ? $wc->wrapperSize() : '' ?>">
		<div class="grid-x grid-padding-x">
			<div class="small-12 medium-7 large-7 cell">
				<div class="animated fadeIn input-group no-margin">
					<span class="input-group-label color-bg-transparent no-border">SØG HER</span>
					<input type="text" class="text-center input-group-field" placeholder="SØG">
					<div class="input-group-button">
						<input type="submit" class="button sr-btn contain center-center no-repeat" value="SØG">
					</div>
				</div>
			</div>
			<div class="small-12 medium-5 large-5 cell">
				<div class="grid-x grid-padding-x">
					<div class="small-12 medium-6 large-6 cell">
						<label>
							<select class="animated fadeIn no-margin">
								<option disabled value="" selected hidden>KATEGORI</option>
								<option value="husker">Husker</option>
								<option value="starbuck">Starbuck</option>
								<option value="hotdog">Hot Dog</option>
								<option value="apollo">Apollo</option>
							</select>
						</label>
					</div>
					<div class="small-12 medium-6 large-6 cell">
						<label>
							<select class="animated fadeIn no-margin">
								<option disabled value="" selected hidden>FIRMA</option>
								<option value="husker">Husker</option>
								<option value="starbuck">Starbuck</option>
								<option value="hotdog">Hot Dog</option>
								<option value="apollo">Apollo</option>
							</select>
						</label>
					</div>
				</div>
			</div>
		</div>
	</form>
</div>