<?php
/**
 * Template part for mobile top bar menu
 *
 * @package fiftytwo
 * @since fiftytwo 1.0.0
 */

?>

<nav class="mobile-menu vertical menu" role="navigation">
	<?php fiftytwo_mobile_nav(); ?>
</nav>
