<div class="page-title bottom-border title-padding">
	<div class="grid-container">
		<div class="cell text-center">
			<?php the_title('<h1 class="wow slideInUp font-35 font-headline case-upper line-height no-margin">', '</h1>'); ?>
		</div>
	</div>
</div>