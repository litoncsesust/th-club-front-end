<?php 
include dirname(dirname(__FILE__)) . '/vendor/autoload.php';
use Nahid\JsonQ\Jsonq;
$q = new Jsonq(dirname(dirname(__FILE__)) . '/data/cars.json');

$make_val = isset($_GET['make']) ? $_GET['make'] : '';
$type_val = isset($_GET['type']) ? $_GET['type'] : '';
$fuel_val = isset($_GET['fuel']) ? $_GET['fuel'] : '';
$retun_val = '';

if($make_val){
	$params = $q->where('FabrikatNavn', '==' , $make_val)->select('FabrikatNavn', 'TypeNavn', 'FuelType', 'LeasingCar')->get(); 

	foreach ($params as $param) {
	  $onlyOrAllLeas = ($param->leasing) ? $param->LeasingCar : 1;
		if ($onlyOrAllLeas) {
			$makersList[] = $param->FabrikatNavn;
			$typesList[] = $param->TypeNavn;
			$fulesList[] = $param->FuelType;
		}
	}

	$uniqueMakersList = array_unique($makersList);
	$uniqueTypesList = array_unique($typesList);
	$uniquefulesList = array_unique(array_filter($fulesList, function($value) { return $value !== ''; }));

	$return['makers'] = $uniqueMakersList;
	$return['types'] = $uniqueTypesList;
	$return['fuels'] = $uniquefulesList; 

	$type_val = '';
	$type_val .= '<option disabled value="" selected hidden>VÆLG TYPE</option>';
	foreach ($return['types'] as $type) {
		$type_val .= '<option value="' . $type . '">' . $type . '</option>';
	}
	$retun_val['type'] = $type_val;

	$fuel_val = '';
	$fuel_val .= '<option disabled value="" selected hidden>VÆLG BRÆNDSTOF</option>';
	foreach ($return['fuels'] as $fuel) {
		$fuel_val .= '<option value="' . $fuel . '">' . $fuel . '</option>';
	}
	$retun_val['fuel'] = $fuel_val;
}

if($type_val){
	$params = $q->where('TypeNavn', '==' , $type_val)->select('FabrikatNavn', 'TypeNavn', 'FuelType', 'LeasingCar')->get(); 

	foreach ($params as $param) {
	  $onlyOrAllLeas = ($param->leasing) ? $param->LeasingCar : 1;
		if ($onlyOrAllLeas) {
			$makersList[] = $param->FabrikatNavn;
			$typesList[] = $param->TypeNavn;
			$fulesList[] = $param->FuelType;
		}
	}

	$uniqueMakersList = array_unique($makersList);
	$uniqueTypesList = array_unique($typesList);
	$uniquefulesList = array_unique(array_filter($fulesList, function($value) { return $value !== ''; }));

	$return['makers'] = $uniqueMakersList;
	$return['types'] = $uniqueTypesList;
	$return['fuels'] = $uniquefulesList; 

	$make_val = '';
	$make_val .= '<option disabled value="" selected hidden>VÆLG MÆRKE</option>';
	foreach ($return['makers'] as $maker) {
		$make_val .= '<option value="' . $maker . '">' . $maker . '</option>';
	}
	$retun_val['make'] = $make_val;

	$fuel_val = '';
	$fuel_val .= '<option disabled value="" selected hidden>VÆLG BRÆNDSTOF</option>';
	foreach ($return['fuels'] as $fuel) {
		$fuel_val .= '<option value="' . $fuel . '">' . $fuel . '</option>';
	}
	$retun_val['fuel'] = $fuel_val;
}

if($fuel_val){
	$params = $q->where('FuelType', '==' , $fuel_val)->select('FabrikatNavn', 'TypeNavn', 'FuelType', 'LeasingCar')->get(); 

	foreach ($params as $param) {
	  $onlyOrAllLeas = ($param->leasing) ? $param->LeasingCar : 1;
		if ($onlyOrAllLeas) {
			$makersList[] = $param->FabrikatNavn;
			$typesList[] = $param->TypeNavn;
			$fulesList[] = $param->FuelType;
		}
	}

	$uniqueMakersList = array_unique($makersList);
	$uniqueTypesList = array_unique($typesList);
	$uniquefulesList = array_unique(array_filter($fulesList, function($value) { return $value !== ''; }));

	$return['makers'] = $uniqueMakersList;
	$return['types'] = $uniqueTypesList;
	$return['fuels'] = $uniquefulesList; 

	$make_val = '';
	$make_val .= '<option disabled value="" selected hidden>VÆLG MÆRKE</option>';
	foreach ($return['makers'] as $maker) {
		$make_val .= '<option value="' . $maker . '">' . $maker . '</option>';
	}
	$retun_val['make'] = $make_val;

	$type_val = '';
	$type_val .= '<option disabled value="" selected hidden>VÆLG TYPE</option>';
	foreach ($return['types'] as $type) {
		$type_val .= '<option value="' . $type . '">' . $type . '</option>';
	}
	$retun_val['type'] = $type_val;

}
echo json_encode($retun_val);

