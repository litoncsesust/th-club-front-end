<?php 
include dirname(dirname(__FILE__)) . '/vendor/autoload.php';
use Nahid\JsonQ\Jsonq;

class SingleProductClass {
	public function __construct($sku) {
		$this->sku = $sku;
	}
	public function singleProduct() {
		try {
			$q = new Jsonq(dirname(dirname(__FILE__)) . '/data/products.json');
			$res = $q->from('result')->where('sku', $this->sku)->get();

			if (sizeof($res) == 0) {
				//wp_redirect(site_url());
				//exit;
			} else {
				$return = '';
				foreach ($res as $key => $val) {
					$return = $val;
				}
				return $return;
			}
		} catch (\Nahid\JsonQ\Exceptions\ConditionNotAllowedException $e) {
		  return $e->getMessage();
		} catch (\Nahid\JsonQ\Exceptions\NullValueException $e) {
		  return $e->getMessage();
		}
	}
}