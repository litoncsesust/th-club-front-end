<?php

class SingleProductAPIClass extends ApiCLass {
	public function __construct($key, $id) {
		$this->key = $key;
		$this->id = $id;
	}

	public function singleProductFromAPI() {
		$token 	= $this->key->access_token;
		$url 		= $this->baseUrl() . 'product/' . $this->id;
		$q 			= $this->fetchClubApiData($token, $url, '');
		return $q->result;
	}
}