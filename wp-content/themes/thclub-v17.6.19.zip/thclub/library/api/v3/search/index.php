<?php
include dirname(dirname(__FILE__)) . '/vendor/autoload.php';
use Nahid\JsonQ\Jsonq;

class SearchClass {
  public function __construct($data) {
    $this->data = $data;
  }
  public function search() {
    $q = new Jsonq(dirname(dirname(__FILE__)) . '/data/products.json');
   
    try {
      $txtSearch = (isset($_GET['txtSearch'])) ? $_GET['txtSearch'] : '';
      $category_id = (isset($_GET['Category'])) ? $_GET['Category'] : '';
      $club_id = (isset($_GET['Club'])) ? $_GET['Club'] : '';
      $search_op = ($txtSearch) ? 'contains' : 'null';
      $category_op = ($category_id) ? '=' : '!='; 
      $club_op = ($club_id) ? '=' : '!='; 


   
      $res = $q->from('result')
        ->where('title', $search_op, $txtSearch)
        //->where('description', $search_op, $txtSearch)
        ->where('category_id', $category_op, $category_id)
        ->where('club_id', $club_op, $club_id)
        ->get();
     
      return $res;
    } catch (\Nahid\JsonQ\Exceptions\ConditionNotAllowedException $e) {
      return $e->getMessage();
    } catch (\Nahid\JsonQ\Exceptions\NullValueException $e) {
      return $e->getMessage();
    }
  }
}