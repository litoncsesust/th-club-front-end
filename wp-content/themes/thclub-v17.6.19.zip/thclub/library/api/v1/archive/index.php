<?php 
include dirname(dirname(__FILE__)) . '/vendor/autoload.php';
use Nahid\JsonQ\Jsonq;

class ArchiveClass {
    protected $leasing;

    public function __construct($leasing) {
      $this->leasing = $leasing;
    }
		
	public function archive() {
		try {
			$q = new Jsonq(dirname(dirname(__FILE__)) . '/data/cars.json');
			$Type = 'Personvogn';
			$res = $q->from('Vehicles')->where('Type', $Type)->get();
			#$res = $q->from('Vehicles')->get();
			return attributes($res, $this->leasing);
		} catch (\Nahid\JsonQ\Exceptions\ConditionNotAllowedException $e) {
		  return $e->getMessage();
		} catch (\Nahid\JsonQ\Exceptions\NullValueException $e) {
		  return $e->getMessage();
		}
	}
}	

function attributes($res, $leasing) {
	$return[] = array();
	$i = 0;
	foreach ($res as $car) { 
    $oldLeas = ($leasing) ? isset($car->LeasingPrice) : !isset($car->LeasingPrice); 
    if ($oldLeas) {
			$return[$i]['id'] = $car->Id;
			$return[$i]['image'] = $car->Pictures[0];
			$return[$i]['name'] = $car->Make . ' ' . $car->Model . ' ' .  $car->Motor . ' ' . $car->Variant;
			$return[$i]['category'] = $car->LeasingPrice ? 'Leasing' : 'Personbil';
			$return[$i]['year'] = $car->Year;
			$return[$i]['mileage'] = $car->Mileage;
			$return[$i]['propellant'] = $car->Propellant;
			$return[$i]['condition'] = $car->Condition;
			$return[$i]['kmpl'] = $car->KmPerLiter;
			$return[$i]['city'] = $car->DealerAddressCity;
			$price = str_replace(",", ".", number_format($car->AdvertisedRetailPrice));
	    $LeasingPrice = str_replace(",", ".", number_format($car->LeasingPrice));
			$return[$i]['price'] = ($price) ?  $price . ' DKK' : $LeasingPrice . ' DKK/md.';
			$i++;
    }
	}
	return $return;
}