<?php

$choices = isset($_GET['cart']) ? $_GET['cart'] : '';
$c = new CartClass($choices);
$c->cart();

?>
<?php if(isset($_SESSION['message'])) { ?>
<div class="grid-container">
  <div class="grid-x align-center">
    <div class="cell small-12 medium-9 large-9 text-center">
      <div class="callout success" data-closable>
        <div class="alert alert-info text-center">
          <?= $_SESSION['message']; ?>
        </div>
        <button class="close-button" aria-label="Dismiss alert" type="button" data-close>
        <span aria-hidden="true">&times;</span>
        </button>
      </div>
    </div>
  </div>
</div>
<?php unset($_SESSION['message']); } ?>

<div class="cart-area extra-top-margin extra-bottom-margin">
  <div class="grid-container">
    <div class="grid-x align-center">
      <div class="cell small-12 medium-9 large-9">
        <form method="POST" action="<?= site_url('cart?cart=save') ?>">
          <table class="table table-bordered table-striped">
            <thead class="case-upper">
              <th></th>
              <th>Product Details</th>
              <th>Point</th>
              <th class="text-center">Quantity</th>
              <th class="text-right">Subtotal</th>
            </thead>
            <tbody>
              <?php
              //initialize total
              $total = 0;
              if(!empty($_SESSION['cart'])){
                //create array of initail qty which is 1               
                $index = 0;
                if(!isset($_SESSION['qty_array'])){
                  $_SESSION['qty_array'] = array_fill(0, count($_SESSION['cart']), 1);
                }

                foreach ($_SESSION['cart'] as $key => $val) {
                  $p = new SingleProductClass($val);
                  $sp = $p->singleProduct();
                  ?>
                  <tr>
                    <td width="10%"><a href="<?= site_url('cart?cart=delete') ?>&id=<?= $sp['id'] ?>&index=<?= $index ?>"><span aria-hidden="true">&times;</span></a></td>
                    <td width="50%"><?= $sp['title'] ?></td>
                    <td width="10%">
                    <?= number_format($sp['initial_point'], 2); ?>
                    <input type="hidden" name="indexes[]" value="<?= $index ?>">
                    </td>
                    <td width="15%"><input type="number" min="1" class="form-control no-margin" value="<?= $_SESSION['qty_array'][$index]; ?>" name="qty_<?= $index ?>"></td>
                    <td width="15%" class="text-right">
                      <?php echo number_format($_SESSION['qty_array'][$index]*$sp['initial_point'], 2); ?>
                    </td>
                    <?php $total += $_SESSION['qty_array'][$index]*$sp['initial_point']; ?>
                  </tr>
                <?php
                  $index ++;
                }
              }
              else{
              ?>
              <tr><td colspan="5" class="text-center">No Item in Cart</td></tr>
              <?php
              }
              ?>
              <tr><td colspan="4" align="right"><b>Total points</b></td><td class="text-right"><b><?= number_format($total, 2); ?></b></td></tr>
            </tbody>
          </table>
          <div class="">
            <a class="case-upper button" href="<?= site_url() ?>">Continue Shopping</a>
            <button type="submit" class="success font-condensed button" name="save">Save Changes</button>
            <a class="case-upper warning button" href="<?= site_url('cart?cart=clear') ?>">Clear Cart</a>
            <a class="case-upper success button" href="<?= site_url('checkout') ?>">Checkout</a>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<script>
  window.history.replaceState({}, document.title, "/" + "dev.th-club.com/cart");
</script>