<?php
	$p = new SingleProductClass(url_last_part());
	$sp = $p->singleProduct();

	$c = new ClubClass($sp['club_id']);
	$cp = $c->singleClub();
?>
<div class="grid-container extra-top-margin">
	<div class="grid-x">
		<div class="cell medium-6 large-8 right-border">
			<div class="product-info">
				<div class="p-image cover center-center no-repeat drop-shadow high-bottom-margin" style="background-image: url(http://test.bordingvista.com/dev.th-club.com/wp-content/themes/thclub/dist/assets/images/products/p6.jpg);"></div>

				<h2 class="medium-bottom-margin"><?= $sp['title'] ?></h2>
				<?php echo $sp['description'] ?>
				<div class="grid-x grid-padding-x small-up-1 medium-up-3 large-up-3 left-border right-border high-top-margin high-bottom-margin">
					<div class="cell text-center">
						<h3 class="no-margin">TIDSPUNKT</h3>
						<p class="font-condensed font-18">MARTS - APRIL</p>
					</div>
					<div class="cell text-center left-border right-border">
						<h3 class="no-margin">LOKATION</h3>
						<p class="font-condensed font-18"><?= $sp['location'] ?></p>
					</div>
					<div class="cell text-center">
						<h3 class="no-margin">BESTIL SENEST</h3>
						<p class="font-condensed font-18"><?= $sp['expire_date'] ?></p>
					</div>
				</div>
			</div>
			<hr>
			<div class="more-info high-top-margin extra-bottom-margin">
				<h2 class="medium-bottom-margin">YDERLIGERE INFORMATION</h2>
				<ul class="inline">
					<li><?= $sp['seller_club']?></li>
					<li><?= $sp['seller_city']?> <?= $sp['seller_postcode']?>,	<?= $sp['seller_address']?></li>
					<li><?= $sp['seller_telephone']?></li>
					<li>KONTAKTPERSON: <?= $sp['seller_email']?></li>
				</ul>
				<?= $sp['seller_description']?>
			</div>
		</div>
		<div class="cell medium-6 large-4">
			<div class="club-info">
				<h2 class="medium-bottom-margin">BESTIL NU</h2>
				<p>FIRMA INFO <a>REDIGER PROFIL</a></p>
			</div>
			<hr>
			<div class="club-info">
				<div class="clearfix">
					<span class="float-left">FIRMA</span>
					<span class="case-upper float-right"><?= $cp['name'] ?></span>
				</div>
				<div class="clearfix">
					<span class="float-left">KONTAKTPERSON</span>
					<span class="case-upper float-right">KLAUS THOMSEN</span>
				</div>
				<div class="clearfix">
					<span class="float-left">EMAIL</span>
					<span class="case-upper float-right"><?= $cp['email'] ?></span>
				</div>
				<div class="clearfix">
					<span class="float-left">TELEFON</span>
					<span class="case-upper float-right"><?= $cp['telephone'] ?></span>
				</div>
			</div>
			<hr>
			<div class="club-info">
				<p>POINTS TILBAGE: <span class="color-text-primary"><?= $sp['initial_point'] ?></span></p>
				<a  href="<?= site_url('/cart?cart=add') ?>&id=<?= $sp['sku'] ?>" id="order" class="font-condensed font-18 button expanded color-bg-primary" type="submit" name="btnOrder" >BESTIL NU</a>
			</div>
		</div>
	</div>
</div>