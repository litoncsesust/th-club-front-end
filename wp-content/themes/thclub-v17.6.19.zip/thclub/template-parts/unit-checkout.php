<?php if ( isset($_POST['btnCheckout']) ) { ?>
<div class="grid-container">
	<div class="grid-x align-center">
		<div class="cell small-12 medium-9 large-9 text-center">
			<div class="callout success" data-closable>
				<?php
					$cart_checkout = new CheckoutClass($_POST);
					$return_response = $cart_checkout->checkout();
					echo "<pre>";
					print_r($return_response);
					exit();
				?>
				<button class="close-button" aria-label="Dismiss alert" type="button" data-close>
				<span aria-hidden="true">&times;</span>
				</button>
			</div>
		</div>
	</div>
</div>
<?php }	?>
<div class="cart-area extra-top-margin extra-bottom-margin">
  <div class="grid-container">
    <div class="grid-x align-center">
      <div class="cell small-12 medium-9 large-9">
        <form method="POST" action="<?= site_url('/checkout') ?>">
          <table class="table table-bordered table-striped">
            <thead class="case-upper">
              <th>Product Details</th>
              <th>Point</th>
              <th class="text-center">Quantity</th>
              <th class="text-right">Subtotal</th>
            </thead>
            <tbody>
              <?php
              //initialize total
              $total = 0;
              if(!empty($_SESSION['cart'])){
              //create array of initail qty which is 1
              $index = 0;
              if(!isset($_SESSION['qty_array'])){
              $_SESSION['qty_array'] = array_fill(0, count($_SESSION['cart']), 1);
              }
              foreach ($_SESSION['cart'] as $key => $val) {
              $p = new SingleProductClass($val);
              $sp = $p->singleProduct();
              ?>
              <tr>
                <td width="50%"><?= $sp['title'] ?></td>
                <td width="10%">
                <?= number_format($sp['initial_point'], 2); ?>
                <input type="hidden" name="<?= $sp['sku'] ?>" value="<?= $_SESSION['qty_array'][$index]; ?>">
                </td>
                <td width="15%"><?= $_SESSION['qty_array'][$index]; ?></td>
                <td width="15%" class="text-right">
                  <?= number_format($_SESSION['qty_array'][$index]*$sp['initial_point'], 2); ?>
                </td>
                <?php $total += $_SESSION['qty_array'][$index]*$sp['initial_point']; ?>
              </tr>
              <?php
              $index ++;
              }
              }
              else{
              ?>
              <tr><td colspan="4" class="text-center">No Item in Cart</td></tr>
              <?php
              }
              ?>
              <tr><td colspan="3" align="right"><b>Total points</b></td><td class="text-right"><b><?= number_format($total, 2); ?></b><input type="hidden" name="total_point" value="<?= $total ?>"></td></tr>
            </tbody>
          </table>
          <div class="">
            <a class="case-upper button" href="<?= site_url() ?>">Continue Shopping</a>
            <button type="submit" class="success font-condensed button" name="btnCheckout">Submit</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>