<?php

	$p = new SingleProductClass(url_last_part());
	$sp = $p->singleProduct();

// Array
// (
//     [id] => 3
//     [title] => 
//     [category_id] => 2
//     [club_id] => 2
//     [location] => 
//     [address] => 
//     [post_code] => 2
//     [city] => 
//     [expire_date] => 2000-01-01
//     [total_number] => 2
//     [initial_point] => 2
//     [description] => 
//     [short_description] =>
//     [created_at] => 
//     [updated_at] => 2019-06-12 05:23:06
//     [files] => Array
//         (
//         )
// )

?>
<div class="grid-container extra-top-margin">
	<div class="grid-x">
		<div class="cell medium-6 large-8 right-border">
			<div class="product-info">
				<div class="p-image cover center-center no-repeat drop-shadow high-bottom-margin" style="background-image: url(http://test.bordingvista.com/dev.th-club.com/wp-content/themes/thclub/dist/assets/images/products/p6.jpg);"></div>

				<h2 class="medium-bottom-margin"><?= $sp['title'] ?></h2>
				<?= $sp['description'] ?>
				<div class="grid-x grid-padding-x small-up-1 medium-up-3 large-up-3 left-border right-border high-top-margin high-bottom-margin">
					<div class="cell text-center">
						<h3 class="no-margin">TIDSPUNKT</h3>
						<p class="font-condensed font-18">MARTS - APRIL</p>
					</div>
					<div class="cell text-center left-border right-border">
						<h3 class="no-margin">LOKATION</h3>
						<p class="font-condensed font-18"><?= $sp['location'] ?></p>
					</div>
					<div class="cell text-center">
						<h3 class="no-margin">BESTIL SENEST</h3>
						<p class="font-condensed font-18">30. FEBRUAR</p>
					</div>
				</div>
			</div>
			<hr>
			<div class="more-info high-top-margin extra-bottom-margin">
				<h2 class="medium-bottom-margin">YDERLIGERE INFORMATION</h2>
				<ul class="inline">
					<li>ATHOME APARTMENTS</li>
					<li>HEDAGER 38, 8200 AARHUS N</li>
					<li>71 99 29 94</li>
					<li>KONTAKTPERSON: SØREN HENRIKSEN</li>
				</ul>
				<p>Ehenis mil moluptassi omnis nos quate di odi is molorib ernatium et ut quam enimi, odi sinci voluptibus ma verspis eroOnsequam fugiasp erchillorum labo. Ri optat modipid emporrorion eum quisci doluptatiunt ea cone arit, od modi tem hiti volectat velit faccus, que sime sitas aut acepudanis voloritas doluptatqui dolendunt, a ditamen dignatustiur Nim litatur, sinum harumqui ipsape cuptat quis ea coremquas dolum volor autem et fugitios con custibu stinvercium que magnat acereiu mquunt.</p>
			</div>
		</div>
		<div class="cell medium-6 large-4">
			<div class="club-info">
				<h2 class="medium-bottom-margin">BESTIL NU</h2>
				<p>FIRMA INFO <a>REDIGER PROFIL</a></p>
			</div>
			<hr>
			<div class="club-info">
				<div class="clearfix">
					<span class="float-left">FIRMA</span>
					<span class="float-right">THOMSEN & CO</span>
				</div>
				<div class="clearfix">
					<span class="float-left">KONTAKTPERSON</span>
					<span class="float-right">KLAUS THOMSEN</span>
				</div>
				<div class="clearfix">
					<span class="float-left">EMAIL</span>
					<span class="float-right">KLAUS@THOMSENOGCO.DK</span>
				</div>
				<div class="clearfix">
					<span class="float-left">TELEFON</span>
					<span class="float-right">45 01 02 03 04</span>
				</div>
			</div>
			<hr>
			<div class="club-info">
				<p>POINTS TILBAGE: <span class="color-text-primary"><?= $sp['initial_point'] ?></span></p>
				<a  href="<?= site_url('/cart?cart=add') ?>&id=<?= $sp['id'] ?>" id="order" class="font-condensed font-18 button expanded color-bg-primary" type="submit" name="btnOrder" >BESTIL NU </a>
			</div>
		</div>
	</div>
</div>