<?php
$cw = get_sub_field('sr_cw');
if ($cw) {
  $w = get_sub_field('sr_w');
  $wc = new WrapperClass($w, ''); 
}
$p = new ProductsClass();

$sc = new SearchClass(false);
$products = (isset($_GET['txtSearch']) || isset($_GET['Category']) || isset($_GET['Club'])) ? $sc->search() : '';
     
/*echo "<pre>";
print_r($products);*/

?>

<div class="sr-area <?= ($cw) ? $wc->marginPadding() : ''?>" <?= ($cw) ? $wc->wrapperStyle() : '' ?>>
	<div class="grid-container <?= ($cw) ? $wc->wrapperSize() : '' ?>">
		<div id="s-result" class="grid-x grid-padding-x small-up-2 medium-up-3 large-up-3 align-center">
		<?php if(isset($_GET['txtSearch']) || isset($_GET['Category']) || isset($_GET['Club'])) { ?>
			<?php foreach ($products as $product) { ?>
				<div class="cell wow slideInUp high-bottom-margin" data-wow-delay="150ms">
					<div class="drop-shadow lazy cover tg-bg-image" style="height: 286.151px; background-image: url(<?= get_template_directory_uri()?>/dist/assets/images/products/p1.jpg "></div>
					<div class="p-info clearfix">
						<a href="<?= site_url() ?>/product/<?= $product['id'] ?>" class="p-name font-condensed font-18 float-left color-text-darkgray"><?= $product['title'] ?></a>
						<a href="<?= site_url() ?>/product/<?= $product['id'] ?>" class="p-price font-condensed font-15 float-right text-center color-bg-primary color-text-white"><?= $product['initial_point'] ?> <br/>POINTS</a>
					</div>
					<a href="<?= site_url() ?>/product/<?= $product['id'] ?>" class="p-link font-condensed font-18 color-text-gray">&rarr; <u>LÆS MERE</u></a><hr/>
				</div>

		<?php } } else { 
			foreach ($p->products() as $product) { ?>
				<div class="cell wow slideInUp high-bottom-margin" data-wow-delay="150ms">
					<div class="drop-shadow lazy cover tg-bg-image" style="height: 286.151px; background-image: url(<?= get_template_directory_uri()?>/dist/assets/images/products/p1.jpg "></div>
					<div class="p-info clearfix">
						<a href="<?= site_url() ?>/product/<?= $product['id'] ?>" class="p-name font-condensed font-18 float-left color-text-darkgray"><?= $product['title'] ?></a>
						<a href="<?= site_url() ?>/product/<?= $product['id'] ?>" class="p-price font-condensed font-15 float-right text-center color-bg-primary color-text-white"><?= $product['initial_point'] ?> <br/>POINTS</a>
					</div>
					<a href="<?= site_url() ?>/product/<?= $product['id'] ?>" class="p-link font-condensed font-18 color-text-gray">&rarr; <u>LÆS MERE</u></a><hr/>
				</div>
		<?php } }?>

		</div>
	</div>
</div>