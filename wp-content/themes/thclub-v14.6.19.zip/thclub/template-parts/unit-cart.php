  <?php 
      if(isset($_SESSION['message'])){
        ?>
        <div class="alert alert-info text-center">
          <?php echo $_SESSION['message']; ?>
        </div>
        <?php
        unset($_SESSION['message']);
      }

      ?>
  <form method="POST" action="<?= site_url('cart?cart=save') ?>">
      <table class="table table-bordered table-striped">
        <thead>
          <th></th>
          <th>Name</th>
          <th>Price</th>
          <th>Quantity</th>
          <th>Subtotal</th>
        </thead>
        <tbody>
          <?php
         

            //initialize total
            $total = 0;
            if(!empty($_SESSION['cart'])){
            //create array of initail qty which is 1
              $index = 0;
              if(!isset($_SESSION['qty_array'])){
                $_SESSION['qty_array'] = array_fill(0, count($_SESSION['cart']), 1);
              }

              foreach ($_SESSION['cart'] as $key => $val) {                
                $p = new SingleProductClass($val);
                $sp = $p->singleProduct();
               
                ?>
                <tr>
                  <td>
                    <a href="<?= site_url('cart?cart=delete') ?>&id=<?= $sp['id'] ?>&index=<?php echo $index; ?>" class="btn btn-danger btn-sm"><span class="glyphicon glyphicon-trash">Delete</span></a>
                  </td>
                  <td><?php echo $sp['title']; ?></td>
                  <td><?php echo number_format($sp['initial_point'], 2); ?></td>
                  <input type="hidden" name="indexes[]" value="<?php echo $index; ?>">
                  <td><input type="number" min="1" class="form-control" value="<?php echo $_SESSION['qty_array'][$index]; ?>" name="qty_<?php echo $index; ?>"></td>
                  <td><?php echo number_format($_SESSION['qty_array'][$index]*$sp['initial_point'], 2); ?></td>
                  <?php $total += $_SESSION['qty_array'][$index]*$sp['initial_point']; ?>
                </tr>
                <?php
                $index ++;
              }
            }
            else{
              ?>
              <tr>
                <td colspan="4" class="text-center">No Item in Cart</td>
              </tr>
              <?php
            }

          ?>
          <tr>
            <td colspan="4" align="right"><b>Total</b></td>
            <td><b><?php echo number_format($total, 2); ?></b></td>
          </tr>
        </tbody>
      </table>
      <a href="<?= site_url() ?>" class="btn btn-primary"><span class="glyphicon glyphicon-arrow-left"></span> Back</a>
      <button type="submit" class="btn btn-success" name="save">Save Changes</button>
      <a href="<?= site_url('cart?cart=clear') ?>" class="btn btn-danger"><span class="glyphicon glyphicon-trash"></span> Clear Cart</a>
      <a href="checkout.php" class="btn btn-success"><span class="glyphicon glyphicon-check"></span> Checkout</a>
      </form>