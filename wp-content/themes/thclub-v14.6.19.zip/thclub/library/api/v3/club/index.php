<?php

class ClubClass extends BaseClass {
	public function __construct() {
	}

	private function accessToken() {
		return array(
			'headers' => array(
				'Content-type' => 'application/json',
				'Authorization' => isset($_SESSION['clubKey']->access_token) ? $_SESSION['clubKey']->access_token : ''
			)
		);
	}
	
	public function clubs() {
		$url = $this->baseUrl() . 'clubs';
		if(wp_remote_get($url, $this->accessToken() )['response']['code'] != 404){
			$c_response = wp_remote_get($url, $this->accessToken() );
			$c_data = wp_remote_retrieve_body($c_response);
			return json_decode($c_data, true);
		}
	}
}