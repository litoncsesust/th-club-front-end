<?php

class SingleUserClass extends ApiCLass {
	public function __construct($key) {
		$this->key = $key;
	}

	public function user() {
		$token 	= $this->key->access_token;
		$url 		= $this->baseUrl() . 'user/' . $this->key->id;
		return $this->fetchClubApiData($token, $url, '');
	}
}