<?php

class CategoryClass extends BaseClass {
	public function __construct() {
	}

	private function accessToken() {
		return array(
			'headers' => array(
				'Content-type' => 'application/json',
				'Authorization' => isset($_SESSION['clubKey']->access_token) ? $_SESSION['clubKey']->access_token : ''
			)
		);
	}
	
	public function categories() {
		$url = $this->baseUrl() . 'categories';
		if(wp_remote_get($url, $this->accessToken() )['response']['code'] != 404){
			$category_response = wp_remote_get($url, $this->accessToken() );
			$category_data = wp_remote_retrieve_body($category_response);
			return json_decode($category_data, true);
		}
	}
}