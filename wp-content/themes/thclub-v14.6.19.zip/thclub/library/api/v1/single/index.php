<?php
include dirname(dirname(__FILE__)) . '/vendor/autoload.php';
use Nahid\JsonQ\Jsonq;
class SingleCarClass {
	protected $id;
	public function __construct($id) {
		$this->id = $id;
	}
	public function singleCar() {
		try {
			$q = new Jsonq(dirname(dirname(__FILE__)) . '/data/cars.json');
			$res = $q->from('Vehicles')
			->where('Id', $this->id)
			->get();
			$return = '';
			foreach ($res as $key => $val) {
				$return = $val;
			}
			return $return;

		} catch (\Nahid\JsonQ\Exceptions\ConditionNotAllowedException $e) {
			return $e->getMessage();
		} catch (\Nahid\JsonQ\Exceptions\NullValueException $e) {
			return $e->getMessage();
		}
	}
}