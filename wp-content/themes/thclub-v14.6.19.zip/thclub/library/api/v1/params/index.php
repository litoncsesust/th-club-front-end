<?php 
include dirname(dirname(__FILE__)) . '/vendor/autoload.php';
use Nahid\JsonQ\Jsonq;

class ParamClass {
	protected $make;
  protected $type;
  protected $propellant;
  protected $leasing;

  public function __construct($make, $type, $propellant, $leasing) {
  $this->make = $make;
    $this->type = $type;
    $this->propellant = $propellant;
    $this->leasing = $leasing;
  }

	public function params() {
		try {
			$q = new Jsonq(dirname(dirname(__FILE__)) . '/data/cars.json');
			$params = $q->from('Vehicles')->select('Make', 'Type', 'Propellant', 'LeasingPrice')->get();      
			$makersList = array();
			foreach ($params as $param) {
        $onlyOrAllLeas = ($this->leasing) ? isset($param->LeasingPrice) : !isset($param->LeasingPrice); 
				if ($onlyOrAllLeas) {
					$makersList[] = $param->Make;
					$typesList[] = $param->Type;
					$fulesList[] = $param->Propellant;
				}
			}
			$uniqueMakersList = array_unique($makersList);
			$uniqueTypesList = array_unique($typesList);
			$uniquefulesList = array_unique($fulesList);
			
			$return['makers'] = $uniqueMakersList;
			$return['types'] = $uniqueTypesList;
			$return['fuels'] = $uniquefulesList; 
			return $return;
		} catch (\Nahid\JsonQ\Exceptions\ConditionNotAllowedException $e) {
		  return $e->getMessage();
		} catch (\Nahid\JsonQ\Exceptions\NullValueException $e) {
		  return $e->getMessage();
		}
	}
}	