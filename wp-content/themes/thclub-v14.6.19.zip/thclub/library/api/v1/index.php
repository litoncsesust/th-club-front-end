<?php

include 'params/index.php';
