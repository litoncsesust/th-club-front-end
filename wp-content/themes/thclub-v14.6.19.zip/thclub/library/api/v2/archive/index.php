<?php 
include dirname(dirname(__FILE__)) . '/vendor/autoload.php';
use Nahid\JsonQ\Jsonq;

class ArchiveClass {
    protected $leasing;

    public function __construct($leasing) {
      $this->leasing = $leasing;
    }
		
	public function archive() {
		try {
			$q = new Jsonq(dirname(dirname(__FILE__)) . '/data/cars.json');
			$Type = 'Personbil';

			$min = (isset($_GET['min'])) ? $_GET['min'] : 0;
			$max = (isset($_GET['max'])) ? $_GET['max'] : 0;	
			$min = $this->removeDot($min);
			$max = $this->removeDot($max);

			$min_op = ($min) ? '>=' : '!=='; 
			$max_op = ($max) ? '<=' : '!=='; 

			$res = $q->where('TypeNavn', $Type)
			->where('carPrice', $min_op, $min)
			->where('carPrice', $max_op, $max)
			->get();
	 
			return attributes($res, $this->leasing);
		} catch (\Nahid\JsonQ\Exceptions\ConditionNotAllowedException $e) {
		  return $e->getMessage();
		} catch (\Nahid\JsonQ\Exceptions\NullValueException $e) {
		  return $e->getMessage();
		}
	}
	private function removeDot($normal) {
    return str_replace(".", "", $normal);
	}
}	

function attributes($res, $leasing) {
	$return[] = array();
	$i = 0;
	foreach ($res as $car) { 
	$oldLeas = ($leasing) ? $car->LeasingCar : 1;
    if ($oldLeas) {
			$return[$i]['id'] = $car->KoeretoejId;
			$return[$i]['image'] = $car->ImageIds[0]['Id'];
			$return[$i]['name'] = $car->FabrikatNavn . ' ' . $car->ModelNavn . ' ' .  $car->VariantBetegnelse;
			$return[$i]['category'] = $car->TypeNavn;
			$return[$i]['Reg1Aar'] = $car->Reg1Aar;
			$return[$i]['mileage'] = $car->Km;
			$return[$i]['propellant'] = $car->FuelType;
			$return[$i]['condition'] = $car->Energiklasse;
			$return[$i]['kmpl'] = $car->DrivmiddelforbrugKMprL;
			$return[$i]['city'] = $car->DealerAddressCity;
			$return[$i]['carPrice'] = $car->carPrice;
			$i++;
    }
	}
	return $return;
}