<?php
include dirname(dirname(__FILE__)) . '/vendor/autoload.php';
use Nahid\JsonQ\Jsonq;

class PriceClass {
	protected $min_amount = 0;
	protected $max_amount = 0;

	public function __construct() {
	}

	public function getMinMaxPrice() {
		$min_max = [];
		try {
			$q = new Jsonq(dirname(dirname(__FILE__)) . '/data/cars.json');

			$Make = (isset($_GET['Make'])) ? $_GET['Make'] : false;
			//$Type = (isset($_GET['Type'])) ? $_GET['Type'] : false;
			$Fuel = (isset($_GET['Fuel'])) ? $_GET['Fuel'] : false;
			$Type = 'Personbil';

			$Make_op = ($Make && (strcmp($Make, 'all') !== 0)) ? '==' : '!=='; 
			$Type_op = ($Type && (strcmp($Type, 'all') !== 0)) ? '==' : '!=='; 
			$Fuel_op = ($Fuel && (strcmp($Fuel, 'all') !== 0)) ? '==' : '!=='; 

			$min_max['min_amount'] = $q->where('FabrikatNavn',$Make_op, $Make)
			->where('TypeNavn',$Type_op, $Type)
			->where('FuelType',$Fuel_op, $Fuel)
			->min('carPrice');

			$min_max['max_amount'] = $q->where('FabrikatNavn',$Make_op, $Make)
			->where('TypeNavn',$Type_op, $Type)
			->where('FuelType',$Fuel_op, $Fuel)
			->max('carPrice');
			
			return $min_max;
		} catch (\Nahid\JsonQ\Exceptions\ConditionNotAllowedException $e) {
		  return $e->getMessage();
		} catch (\Nahid\JsonQ\Exceptions\NullValueException $e) {
		  return $e->getMessage();
		}
	}
}