<?php

class LeasingCarListingClass {

	private $token = 'Token 12f3e8a6873ed33f63d0171e0198f6df6eae5aeb';
  private $offers_api_url = 'https://www.findleasing.nu/api/offers/';
  private $leasing_api_url = 'https://www.findleasing.nu/api/car-listings/';

  private function args() {
		return array('headers' => array('Content-type' => 'application/json', 'Authorization' => $this->token));
	}

	public function offerCarListing() {
		$page_offer_data = [];
		for ($i=1; $i <=500 ; $i++) { 
			$offers_api_url = $this->offers_api_url . '?page=' . $i . '&show_in_iframe=true';
			if(wp_remote_get($offers_api_url, $this->args() )['response']['code'] == 404){
				break;
			}
			$offers_response = wp_remote_get($offers_api_url, $this->args() );
			$offers_data = wp_remote_retrieve_body( $offers_response );
			$offers_data = json_decode($offers_data, true);
			$page_offer_data = ($i >= 2) ? array_merge($page_offer_data, $offers_data['results']) : $offers_data['results'];
		}
	
		foreach ($page_offer_data as $key => $val) {  
			$page_offer_data[$key]['car_make'] = $this->addCM($val);
			$page_offer_data[$key]['fuel_type'] = $this->addFT($val);
			$page_offer_data[$key]['leasing'] = $this->addLT($val);
			$page_offer_data[$key]['page_id'] = $this->addPageID($val);
		}

		$ocf = fopen(dirname(dirname(__FILE__)) . '/data/offercars.json', 'w');
		fwrite($ocf, json_encode($page_offer_data, true));
		fclose($ocf);
	}

	private function addCM($data = null) {
		return $data['car']['make'];
	}
	private function addFT($data = null) {
		return $data['car']['fuel_type'];
	}
	private function addLT($data = null) {
		return $data['leasing_type']['text'];
	}

	private function addPageID($data = null) {
		$id = str_split($data['id']);
		$wordtonumber = [];
		$i=0;
		foreach ($id as $key => $val) {
		  $wordtonumber[$i] = is_numeric($val) ? $val : $this->toNumber($val) ;
		  $i++;
		}
		return implode($wordtonumber);
	}

	private function toNumber($dest) {
	  if ($dest) {
	    return ord(strtolower($dest)) - 96;
	  } else {
	    return 0;
	  }
	}
}