<?php
include get_template_directory() . '/library/api/v2/vendor/autoload.php';
use Nahid\JsonQ\Jsonq;
class LeasingSingleCarClass {
	protected $id;
	public function __construct($id) {
		$this->id = $id;
	}
	public function leasingSingleCar() {
		try {
			$q = new Jsonq(dirname(dirname(__FILE__)) . '/data/leasingcars.json');
			$res = $q->where('id', $this->id)->get();
			$return = '';
			foreach ($res as $key => $val) {
				$return = $val;
			}
			return $return;
		} catch (\Nahid\JsonQ\Exceptions\ConditionNotAllowedException $e) {
			return $e->getMessage();
		} catch (\Nahid\JsonQ\Exceptions\NullValueException $e) {
			return $e->getMessage();
		}
	}
}