<?php 

include get_template_directory() . '/library/api/v2/vendor/autoload.php';
use Nahid\JsonQ\Jsonq;

class OffersParamClass {
  protected $make;
  protected $type;
  protected $fuel;

  public function __construct($make, $type, $fuel) {
  	$this->make = $make;
    $this->type = $type;
    $this->fuel = $fuel;
  }

	public function offersParams() {
		try {
			$q = new Jsonq(dirname(dirname(__FILE__)) . '/data/offercars.json');
			$params = $q->select('car_make', 'leasing', 'fuel_type')->get(); 
			
			$makersList = array();
			$typesList = array();
			$fulesList = array();
			
			foreach ($params as $param) {
				$makersList[] = $param->car_make;
				$typesList[] = $param->leasing;
				$fulesList[] = $param->fuel_type;
			}

			$uniqueMakersList = array_unique($makersList);
			$uniqueTypesList = array_unique($typesList);
			$uniquefulesList = array_unique(array_filter($fulesList, function($value) { return $value !== ''; }));

			$return['makers'] = $uniqueMakersList;
			$return['types'] = $uniqueTypesList;
			$return['fuels'] = $uniquefulesList;

			return $return;
		} catch (\Nahid\JsonQ\Exceptions\ConditionNotAllowedException $e) {
		  return $e->getMessage();
		} catch (\Nahid\JsonQ\Exceptions\NullValueException $e) {
		  return $e->getMessage();
		}
	}
}	

class LeasingParamClass {
  protected $make;
  protected $type;
  protected $fuel;

  public function __construct($make, $type, $fuel) {
  	$this->make = $make;
    $this->type = $type;
    $this->fuel = $fuel;
  }

	public function leasingParams() {
		try {
			$q = new Jsonq(dirname(dirname(__FILE__)) . '/data/leasingcars.json');
			$params = $q->select('make_name', 'LeasingType', 'FuelType')->get(); 
			
			$makersList = array();
			$typesList = array();
			$fulesList = array();
			
			foreach ($params as $param) {
				$makersList[] = $param->make_name;
				$typesList[] = $param->LeasingType;
				$fulesList[] = $param->FuelType;
			}

			$uniqueMakersList = array_unique($makersList);
			$uniqueTypesList = array_unique($typesList);
			$uniquefulesList = array_unique(array_filter($fulesList, function($value) { return $value !== ''; }));

			$return['makers'] = $uniqueMakersList;
			$return['types'] = $uniqueTypesList;
			$return['fuels'] = $uniquefulesList; 
			return $return;
		} catch (\Nahid\JsonQ\Exceptions\ConditionNotAllowedException $e) {
		  return $e->getMessage();
		} catch (\Nahid\JsonQ\Exceptions\NullValueException $e) {
		  return $e->getMessage();
		}
	}
}	