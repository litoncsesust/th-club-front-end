<?php

class CarListingClass {
  public function carListing() {
    //$url = "https://services.web.bilinfo.dk/api/vehicle/?user=Matchbiler&password=G2222WpCVX&format=json";
    $url = 'http://api.autoit.dk/car/GetCarsExtended/4548D748-7649-461E-8282-DF34F0CB3C37';
    header('Content-Type: application/json');
    $data = json_decode(file_get_contents($url), true);
    foreach ($data as $key => $val) {           
      /*====================Image save local folder====================*/
      foreach ($val['ImageIds'] as $k => $v) {
        $imageId = $v['Id'];
        $imgUrl = "http://imageapi.autoit.dk/ImageService.svc/GetVehicleImageFromImageId/".$imageId."/500";
        $img = $_SERVER['DOCUMENT_ROOT'] . '/dev.matchbiler.dk/images/500/'.$imageId.'.jpg';
        if (!file_exists($img)) {
          file_put_contents($img, file_get_contents($imgUrl));
        }
      }
      foreach ($val['ImageIds'] as $k => $v) {
        $imageId = $v['Id'];
        $imgUrl = "http://imageapi.autoit.dk/ImageService.svc/GetVehicleImageFromImageId/".$imageId."/300";
        $img = $_SERVER['DOCUMENT_ROOT'] . '/dev.matchbiler.dk/images/300/'.$imageId.'.jpg';
        if (!file_exists($img)) {
          file_put_contents($img, file_get_contents($imgUrl));
        }
      }
      foreach ($val['ImageIds'] as $k => $v) {
        $imageId = $v['Id'];
        $imgUrl = "http://imageapi.autoit.dk/ImageService.svc/GetVehicleImageFromImageId/".$imageId."/1000";
        $img = $_SERVER['DOCUMENT_ROOT'] . '/dev.matchbiler.dk/images/1000/'.$imageId.'.jpg';
        if (!file_exists($img)) {
            file_put_contents($img, file_get_contents($imgUrl));
        }
      }
      foreach ($val['ImageIds'] as $k => $v) {
        $imageId = $v['Id'];
        $imgUrl = "http://imageapi.autoit.dk/ImageService.svc/GetVehicleImageFromImageId/".$imageId."/400";
        $img = $_SERVER['DOCUMENT_ROOT'] . '/dev.matchbiler.dk/images/400/'.$imageId.'.jpg';
        if (!file_exists($img)) {
          file_put_contents($img, file_get_contents($imgUrl));
        }
      }
          /*=====================Image save local folder===================*/
      $data[$key]['FuelType'] = $this->addFuelType($val);
      $data[$key]['LeasingCar'] = $this->addLeasing($val);
      $data[$key]['carPrice'] = $this->addPrice($val);
    }

    echo '<pre>';
    print_r($data);
    exit();

    $fp = fopen(dirname(dirname(__FILE__)) . '/data/cars.json', 'w');
    fwrite($fp, json_encode($data, true));
    fclose($fp);
  }

  private function addFuelType($data = null) {
    return ($data['DrivmiddelTypeId'] == 'D') ? 'Diesel' : (($data['DrivmiddelTypeId'] == 'B') ? 'Benzin' : 'EL');
    // foreach ($data['StatusTyper'] as $k => $v) {
    //  if ($v['StatusId'] == '-4' || $v['StatusId'] == '-5') {
    //      $retunFuel = $v['StatusNavn'];
    //  }
    // }
  }

  private function addLeasing($data = null) {
    $retunLeasing = '';
    foreach ($data['StatusTyper'] as $k => $v) {
      if ($v['StatusId'] == '12') {
        $retunLeasing = 1;
      }
    }
    return $retunLeasing;
  }

  private function addPrice($car = null) {        
    $PrisDetailDkk = (($car['PrisDetailDkk']) ? $car['PrisDetailDkk'] : 0) + (($car['LeveringsomkostningerDetailDkk']) ? $car['LeveringsomkostningerDetailDkk'] : 0);
    $carPrice = ($PrisDetailDkk) ?  $PrisDetailDkk : '00';
    return $carPrice;
  }
}