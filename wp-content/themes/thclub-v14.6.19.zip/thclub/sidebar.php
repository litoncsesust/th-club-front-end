<?php
/**
 * The sidebar containing the main widget area
 *
 * @package fiftytwo
 * @since fiftytwo 1.0.0
 */

?>
<aside class="sidebar">
	<?php dynamic_sidebar( 'sidebar-widgets' ); ?>
</aside>