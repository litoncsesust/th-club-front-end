<?php

class RegisterClass extends ApiCLass {
  public function __construct($data) {
    $this->data = $data;
  }
  public function register() {
    $url = $this->baseUrl() . 'register';
    $body = array(
      'email'             => isset($this->data['txtEmail']) ? $this->data['txtEmail'] : '',
      'password'          => isset($this->data['txtPassword']) ? $this->data['txtPassword'] : '',
      'name'              => isset($this->data['txtCompanyName']) ? $this->data['txtCompanyName'] : '',
      'telephone'         => isset($this->data['txtTelephone']) ? $this->data['txtTelephone'] : '',
      'cvr_number'        => isset($this->data['txtCVR']) ? $this->data['txtCVR'] : '',
      'address'           => isset($this->data['txtAddress']) ? $this->data['txtAddress'] : '',
      'post_code'         => isset($this->data['txtPost']) ? $this->data['txtPost'] : '',
      'city'              => isset($this->data['txtCity']) ? $this->data['txtCity'] : '',
      'profile_picture'   => isset($this->data['file_path']) ?  array( 'file_path' => $this->data['file_path'], 'file_name'=> $this->data['file_name'] )  : '',
      'short_description' => isset($this->data['txtDescription']) ? $this->data['txtDescription'] : '',
      'point'             => isset($this->data['user_point']) ? $this->data['user_point'] : '',
    );

    $r = $this->fetchClubApiData('', $url, $body, 'post');
    
    if (strcmp($r->status, 'success') == 0) {
      $_SESSION['clubKey'] = $r->result;
      wp_redirect(site_url());
      exit;
    } else {
      print_r($r->result);
    }
  }
}