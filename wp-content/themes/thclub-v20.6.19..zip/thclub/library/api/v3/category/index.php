<?php

include dirname(dirname(__FILE__)) . '/vendor/autoload.php';
use Nahid\JsonQ\Jsonq;

class CategoryClass {
	public function category() {
		try {
			$q = new Jsonq(dirname(dirname(__FILE__)) . '/category/categories.json');
			return $q->from('result')->get();
			 
		} catch (\Nahid\JsonQ\Exceptions\ConditionNotAllowedException $e) {
		  return $e->getMessage();
		} catch (\Nahid\JsonQ\Exceptions\NullValueException $e) {
		  return $e->getMessage();
		}
	}
}