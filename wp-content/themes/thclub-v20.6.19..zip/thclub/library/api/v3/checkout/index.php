<?php

class CheckoutClass extends ApiCLass {
  public function __construct($data) {
    $this->data = $data;
  }
  public function checkout() {
    $url = $this->baseUrl() . 'order';
    $body = array(
      'data'             => isset($this->data) ? $this->data : '',
      'user_id'         => isset($_SESSION['clubKey']->id) ? $_SESSION['clubKey']->id : '',
    );

    $r = $this->fetchClubApiData('', $url, $body, 'post');
   
    if (strcmp($r->status, 'success') == 0) {
      $_SESSION['clubKey'] = $r->result;
      unset($_SESSION['qty_array']);
      unset($_SESSION['cart']);
      wp_redirect(site_url());
      exit;
    } else {
      print_r($r->result);
    }
  }
}