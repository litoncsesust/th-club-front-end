<?php
include dirname(dirname(__FILE__)) . '/vendor/autoload.php';
use Nahid\JsonQ\Jsonq;
 
class SearchClass {
  protected $leasing;

  public function __construct($leasing) {
    $this->leasing = $leasing;
  }

	public function search() {
		$q = new Jsonq(dirname(dirname(__FILE__)) . '/data/cars.json');

		try {
			$Make = (isset($_GET['Make'])) ? $_GET['Make'] : false;
			$Type = (isset($_GET['Type'])) ? $_GET['Type'] : false;
			$Fuel = (isset($_GET['Fuel'])) ? $_GET['Fuel'] : false;
			
			if ($Make && (!$Type) && (!$Fuel)) {
				$res = $q->from('Vehicles')->where('Make', $Make)->get();
			} elseif ($Type && (!$Fuel) && (!$Make)) {
				$res = $q->from('Vehicles')->where('Type', $Type)->get();
			} elseif ($Fuel && (!$Make) && (!$Type)) {
				$res = $q->from('Vehicles')->where('Propellant', $Fuel)->get();
			} elseif ($Make && $Type && (!$Fuel)) {
				$res = $q->from('Vehicles')->where('Make', $Make)->where('Type', $Type)->get();
			} elseif ($Type && $Fuel && (!$Make)) {
				$res = $q->from('Vehicles')->where('Type', $Type)->where('Propellant', $Fuel)->get();
			} elseif ($Fuel && $Make && (!$Type)) {
				$res = $q->from('Vehicles')->where('Make', $Make)->where('Propellant', $Fuel)->get();
			} else {
				$res = $q->from('Vehicles')->where('Make', $Make)->where('Type', $Type)->where('Propellant', $Fuel)->get();
			}
			return attributes($res, $this->leasing);
		} catch (\Nahid\JsonQ\Exceptions\ConditionNotAllowedException $e) {
			return $e->getMessage();
		} catch (\Nahid\JsonQ\Exceptions\NullValueException $e) {
			return $e->getMessage();
		}
	}  
}