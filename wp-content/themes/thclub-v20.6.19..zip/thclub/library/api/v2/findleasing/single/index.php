<?php
include get_template_directory() . '/library/api/v2/vendor/autoload.php';
use Nahid\JsonQ\Jsonq;

class OffersSingleCarClass {

	private $token = 'Token 12f3e8a6873ed33f63d0171e0198f6df6eae5aeb';
  private $offers_api_url = 'https://www.findleasing.nu/api/offers/';
  private function args() {
		return array('headers' => array('Content-type' => 'application/json', 'Authorization' => $this->token));
	}

	protected $id;

	public function __construct($id) {
		$this->id = $id;
	}
	public function offersSingleCar() {
		try {
			$q = new Jsonq(dirname(dirname(__FILE__)) . '/data/offercars.json');
			$res = $q->where('page_id', $this->id)->get();
			$return = '';
			foreach ($res as $key => $val) {
				$return = $val;
			}

			$c = dirname(dirname(__FILE__)) . '/single/'. $return->id .'.json';
      if (!file_exists($c) && ((time() - (60*60*3)) > strtotime($filetime))) {
				$this->storeSingleCarData($return->id);
      } else {
      	$d = new Jsonq(dirname(dirname(__FILE__)) . '/single/'. $return->id .'.json');
      	$carres = $d->get();
      }
			return $carres;
		} catch (\Nahid\JsonQ\Exceptions\ConditionNotAllowedException $e) {
			return $e->getMessage();
		} catch (\Nahid\JsonQ\Exceptions\NullValueException $e) {
			return $e->getMessage();
		}
	}

	public function storeSingleCarData($id) {
		$offer_single_car_url = $this->offers_api_url . $id;
		$offer_single_car = wp_remote_get( $offer_single_car_url, $this->args() );
		// Is the API up?
		if ( ! 200 == wp_remote_retrieve_response_code( $offer_single_car ) ) {
			return false;
		}
		$single_cara_data = wp_remote_retrieve_body( $offer_single_car );
		$single_cara_data = json_decode($single_cara_data, true);
		$scd = fopen(dirname(dirname(__FILE__)) . '/single/'. $id .'.json', 'w');
		fwrite($scd, json_encode($single_cara_data, true));
		fclose($scd);
	}
}