<?php 
include get_template_directory() . '/library/api/v2/vendor/autoload.php';
use Nahid\JsonQ\Jsonq;

class LeasingArchiveClass {		
	public function leasingArchive() {
		try {
			$q = new Jsonq(dirname(dirname(__FILE__)) . '/data/leasingcars.json');
			// $Type = 'Personbil';

			// $min = (isset($_GET['min'])) ? $_GET['min'] : 0;
			// $max = (isset($_GET['max'])) ? $_GET['max'] : 0;

			// if ($min && $max) {
			// 	$res = $q->where('TypeNavn', $Type)->where('carPrice', '>=', $min)->where('carPrice', '<=', $max)->get();
			// } else {
			// 	$res = $q->where('TypeNavn', $Type)->get();			
			// }
			
			$res = $q->get();

			return leasingAttributes($res);
		} catch (\Nahid\JsonQ\Exceptions\ConditionNotAllowedException $e) {
		  return $e->getMessage();
		} catch (\Nahid\JsonQ\Exceptions\NullValueException $e) {
		  return $e->getMessage();
		}
	}
}	

function leasingAttributes($res) {
	$return[] = array();
	$i = 0;
	foreach ($res as $car) { 
		$return[$i]['id'] = $car->id;
		$return[$i]['image'] = $car->thumbnail_url;
		$return[$i]['name'] = $car->full_header;
		$return[$i]['category'] = $car->LeasingType;
		$return[$i]['Reg1Aar'] = $car->year;
		$return[$i]['mileage'] = $car->mileage;
		$return[$i]['propellant'] = $car->FuelType;
		$return[$i]['condition'] = $car->Energiklasse;
		$return[$i]['kmpl'] = $car->fuel_capacity_in_l;
		$return[$i]['city'] = $car->DealerAddressCity;
		$return[$i]['carPrice'] = $car->total_cost;
		$i++;
	}
	return $return;
}