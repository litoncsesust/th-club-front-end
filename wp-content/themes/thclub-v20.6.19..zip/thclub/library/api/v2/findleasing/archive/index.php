<?php 
include get_template_directory() . '/library/api/v2/vendor/autoload.php';
use Nahid\JsonQ\Jsonq;

class OffersArchiveClass {		
	public function offersArchive() {
		try {
			$q = new Jsonq(dirname(dirname(__FILE__)) . '/data/offercars.json');			
			$res = $q->get();
			return offersAttributes($res);
		} catch (\Nahid\JsonQ\Exceptions\ConditionNotAllowedException $e) {
		  return $e->getMessage();
		} catch (\Nahid\JsonQ\Exceptions\NullValueException $e) {
		  return $e->getMessage();
		}
	}
}	

function offersAttributes($res) {
	$return[] = array();
	$i = 0;
	foreach ($res as $car) { 
		$return[$i]['id'] = $car->id;
		$return[$i]['page_id'] = $car->page_id;
		$return[$i]['image'] = $car->thumbnail;
		$return[$i]['title'] = $car->title;
		$return[$i]['leasing'] = $car->leasing;
		$return[$i]['name'] = $car->full_title;
		$return[$i]['make'] = $car->car['make'];
		$return[$i]['model'] = $car->car['model'];
		$return[$i]['Reg1Aar'] = $car->car['year'];
		$return[$i]['mileage'] = $car->car['mileage'];
		$return[$i]['propellant'] = $car->fuel_type;
		$return[$i]['condition'] = $car->state['text'];
		$return[$i]['efficiency'] = $car->car['efficiency'];
		$return[$i]['carPrice'] = $car->price_monthly;
		$i++;
	}
	return $return;
}