<?php

class LeasingCarListingClass {
	protected $token = 'Token 12f3e8a6873ed33f63d0171e0198f6df6eae5aeb';
  protected $args = array('headers' => array('Content-type' => 'application/json', 'Authorization' => $token));
  protected $offers_api_url = 'https://www.findleasing.nu/api/offers/';
  protected $leasing_api_url = 'https://www.findleasing.nu/api/car-listings/';

  public function __construct() {
  	$this->token = $token;
    $this->args = $args;
    $this->offers_api_url = $offers_api_url;
    $this->leasing_api_url = $leasing_api_url;
  }
	private function getOfferData(){
		$token = 'Token 12f3e8a6873ed33f63d0171e0198f6df6eae5aeb';
		$args = array('headers' => array('Content-type' => 'application/json', 'Authorization' => $token));

		$page_offer_data = [];
		for ($i=1; $i <=500 ; $i++) { 
			$offers_api_url = 'https://www.findleasing.nu/api/offers/?page='.$i;
			if(wp_remote_get( $offers_api_url, $args )['response']['code'] == 404){
				break;
			}
			$offers_response = wp_remote_get( $offers_api_url, $args );
			$offers_data = wp_remote_retrieve_body( $offers_response );
			$offers_data = json_decode($offers_data, true);
			$page_offer_data = array_merge($page_offer_data, $offers_data['results']);
		}

		$offers_data_arr = [];
		
		$i=0;
		foreach ($page_offer_data as $key => $val) {
			$offers_data_arr[$i] = $val;
			$i++;
		}

		return $offers_data_arr;
	}

	public function leasingCarListing() {
		$leasing_api_url = 'https://www.findleasing.nu/api/car-listings/';
		$offers_api_url = 'https://www.findleasing.nu/api/offers/';

		$token = 'Token 12f3e8a6873ed33f63d0171e0198f6df6eae5aeb';
		$args = array(
			'headers' => array(
				'Content-type' => 'application/json',
				'Authorization' => $token
			)
		);


		$leasing_response = wp_remote_get( $leasing_api_url, $args );
		$offers_response = wp_remote_get( $offers_api_url, $args );
		// Is the API up?
		if ( ! 200 == wp_remote_retrieve_response_code( $leasing_response ) ) {
			return false;
		}
		if ( ! 200 == wp_remote_retrieve_response_code( $offers_response ) ) {
			return false;
		}

		$leasing_data = wp_remote_retrieve_body( $leasing_response );
		$leasing_data = json_decode($leasing_data, true);

		$offers_data = wp_remote_retrieve_body( $offers_response );
		$offers_data = json_decode($offers_data, true);
		$offers_data_arr = [];
	
		
		foreach ($offers_data['results'] as $key => $val) {
			$offers_data_arr[$val['title']] = $val;
		}
		
		foreach ($leasing_data as $key => $val) {  
			/*=============== Offer API data integration=======================*/
			if (array_key_exists($val['header'], $offers_data_arr)) {				
				$leasing_data[$key]['dataid'] = $offers_data_arr[$val['header']]['id'];
				$leasing_data[$key]['efficiency'] = $offers_data_arr[$val['header']]['car']['efficiency'];
			}
			/*=============== Offer API data integration=======================*/
			$leasing_data[$key]['FuelType'] = $this->addFuelType($val);
			$leasing_data[$key]['LeasingType'] = $this->addLeasingType($val);
		}

		$lcf = fopen(dirname(dirname(__FILE__)) . '/data/leasingcars.json', 'w');
		fwrite($lcf, json_encode($leasing_data, true));
		fclose($lcf);
	}

	public function offerCarListing() {
		$offers_api_url = 'https://www.findleasing.nu/api/offers/';
		$token = 'Token 12f3e8a6873ed33f63d0171e0198f6df6eae5aeb';
		$args = array(
			'headers' => array(
				'Content-type' => 'application/json',
				'Authorization' => $token
			)
		);
		$offers_response = wp_remote_get( $offers_api_url, $args );
		// Is the API up?
		if ( ! 200 == wp_remote_retrieve_response_code( $offers_response ) ) {
			return false;
		}

		$offers_data = wp_remote_retrieve_body( $offers_response );
		$offers_data = json_decode($offers_data, true);

		$offers_data_arr = [];
	
		$page_data = '';
		if ($offers_data['links']['next']) {
			$offers_data_arr = $this->getOfferData();
		}


		$ocf = fopen(dirname(dirname(__FILE__)) . '/data/offercars.json', 'w');
		fwrite($ocf, json_encode($offers_data_arr, true));
		fclose($ocf);
	}


	private function addFuelType($data = null) {
		return ($data['fuel_type'] == '0') ? 'Benzin' : (($data['fuel_type'] == '1') ? 'Diesel' : 'EL');
	}

	private function addLeasingType($data = null) {
		return ($data['leasing_type'] == '0') ? 'Flexleasing' : (($data['leasing_type'] == '2') ? 'Leasing' : '');
	}
}