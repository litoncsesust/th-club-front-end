<?php
include get_template_directory() . '/library/api/v2/vendor/autoload.php';
use Nahid\JsonQ\Jsonq;
 
class OffersSearchClass {
	public function offersSearch() {
		$q = new Jsonq(dirname(dirname(__FILE__)) . '/data/offercars.json');

		try {
			$Make = (isset($_GET['Make'])) ? $_GET['Make'] : false;
			$Type = (isset($_GET['Type'])) ? $_GET['Type'] : false;
			$Fuel = (isset($_GET['Fuel'])) ? $_GET['Fuel'] : false;
 
			$Make_op = ($Make && (strcmp($Make, 'all') !== 0)) ? '==' : '!=='; 
			$Type_op = ($Type && (strcmp($Type, 'all') !== 0)) ? '==' : '!=='; 
			$Fuel_op = ($Fuel && (strcmp($Fuel, 'all') !== 0)) ? '==' : '!=='; 

			$res = $q->where('car_make',$Make_op, $Make)
			->where('leasing',$Type_op, $Type)
			->where('fuel_type',$Fuel_op, $Fuel)
			->get();

			return offersAttributes($res);
		} catch (\Nahid\JsonQ\Exceptions\ConditionNotAllowedException $e) {
			return $e->getMessage();
		} catch (\Nahid\JsonQ\Exceptions\NullValueException $e) {
			return $e->getMessage();
		}
	}  
}