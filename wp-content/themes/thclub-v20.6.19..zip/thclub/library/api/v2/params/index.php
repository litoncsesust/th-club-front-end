<?php 
include dirname(dirname(__FILE__)) . '/vendor/autoload.php';
use Nahid\JsonQ\Jsonq;

class ParamClass {
	protected $make;
  protected $type;
  protected $fuel;
  protected $leasing;

  public function __construct($make, $type, $fuel, $leasing) {
  	$this->make = $make;
    $this->type = $type;
    $this->fuel = $fuel;
    $this->leasing = $leasing;
  }

	public function params() {
		try {
			$q = new Jsonq(dirname(dirname(__FILE__)) . '/data/cars.json');
			$params = $q->select('FabrikatNavn', 'TypeNavn', 'FuelType', 'LeasingCar')->get(); 
			$makersList = array();
			$typesList = array();
			$fulesList = array();
			
			foreach ($params as $param) {
        $onlyOrAllLeas = ($this->leasing) ? $param->LeasingCar : 1;
				if ($onlyOrAllLeas) {
					$makersList[] = $param->FabrikatNavn;
					$typesList[] = $param->TypeNavn;
					$fulesList[] = $param->FuelType;
				}
			}

			$uniqueMakersList = array_unique($makersList);
			$uniqueTypesList = array_unique($typesList);
			$uniquefulesList = array_unique(array_filter($fulesList, function($value) { return $value !== ''; }));

			$return['makers'] = $uniqueMakersList;
			$return['types'] = $uniqueTypesList;
			$return['fuels'] = $uniquefulesList; 
			return $return;
		} catch (\Nahid\JsonQ\Exceptions\ConditionNotAllowedException $e) {
		  return $e->getMessage();
		} catch (\Nahid\JsonQ\Exceptions\NullValueException $e) {
		  return $e->getMessage();
		}
	}
}	