<?php 
include dirname(dirname(__FILE__)) . '/vendor/autoload.php';
use Nahid\JsonQ\Jsonq;

class CarSliderClass {
	protected $make;
  protected $leasing;

	public function __construct($make, $leasing) {
		$this->make = $make;
    $this->leasing = $leasing;
	}

	public function slider() {
		try {
			$q = new Jsonq(dirname(dirname(__FILE__)) . '/data/cars.json');
			$res = ($this->make) ? $q->where('FabrikatNavn', $this->make)->get() : $q->get();
			return slider_attributes($res, $this->leasing);
		} catch (\Nahid\JsonQ\Exceptions\ConditionNotAllowedException $e) {
		  return $e->getMessage();
		} catch (\Nahid\JsonQ\Exceptions\NullValueException $e) {
		  return $e->getMessage();
		}
	}
}	

function slider_attributes($res, $leasing) {
	$return[] = array();
	$i = 0;
	foreach ($res as $car) {
    $oldLeas = ($leasing) ? $car->LeasingCar : 1; 
    if ($oldLeas) {
			$return[$i]['id'] = $car->KoeretoejId;
			$return[$i]['name'] = $car->FabrikatNavn . ' ' . $car->ModelNavn . ' ' .  $car->VariantBetegnelse;
			$price = str_replace(',', '.', number_format(
				(($car->PrisDetailDkk) ? $car->PrisDetailDkk : 0) +
				(($car->LeveringsomkostningerDetailDkk) ? $car->LeveringsomkostningerDetailDkk : 0)
			));
			$LeasingPrice = str_replace(',', '.', number_format($car->LeasingPrice));
			$return[$i]['price'] = ($price) ?  $price . ' DKK' : $LeasingPrice . ' DKK';
			$return[$i]['image'] = $car->ImageIds[0]['Id'];
			$i++;
    }
	}
	return $return;
}