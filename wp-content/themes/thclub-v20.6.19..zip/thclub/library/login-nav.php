<?php
add_filter( 'wp_nav_menu_items', 'fiftytwo_loginout_menu_link', 10, 2 );

function fiftytwo_loginout_menu_link( $items, $args ) {
  if ($args->theme_location == 'top-bar-r' || $args->theme_location == 'mobile-nav' ) {
    if (isset($_SESSION['clubKey'])) {
    	$items .= '<li><a href="'. site_url('create-product') .'">'. __("OPRET PRODUKT") .'</a></li>';
      $items .= '<li><a href="'. site_url('my-profile') .'">'. __("MIN PROFILE") .'</a></li>';
      $items .= '<li><a href="'. site_url('my-products') .'">'. __("MIN PRODUKT") .'</a></li>';
      $items .= '<li class="right color-bg-primary"><a class="color-text-white outline" href="'. site_url('logout') .'">'. __("Log Ud") .'</a></li>';
      $items .= '<li class="cart contain center-center"><a href="'. site_url('cart') .'">'. __("CART") .'</a></li>';
    } else {
      $items .= '<li><a href="'. site_url('create-an-account') .'">'. __("OPRET BRUGER") .'</a></li>';
      $items .= '<li class="right color-bg-primary"><a class="color-text-white outline" data-open="loginForm">'. __("Log ind") .'</a></li>';
      $items .= '<li class="cart contain center-center"><a href="'. site_url('cart') .'">'. __("CART") .'</a></li>';
    }
  }
  return $items;
}