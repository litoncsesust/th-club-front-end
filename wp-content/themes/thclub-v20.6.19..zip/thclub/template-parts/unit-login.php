<div class="reveal" id="loginForm" data-reveal>
	<form class="log-in-form" action="<?= get_the_permalink() ?>" method="post" autocomplete="off">
 		<h4 class="text-center color-text-darkgray font-35 no-margin small-bottom-margin">LOG IND</h4>
		<div class="form-label-group">
			<input type="text" id="loginEmail" name="loginEmail" class="form-control" value="" placeholder="EMAIL ADRESSE" value="<?= isset($_POST['loginEmail']) ? $_POST['loginEmail'] : '' ?>"	autocomplete="off" required>
			<label for="loginEmail">EMAIL ADRESSE</label>
		</div>
		<div class="form-label-group">
			<input type="password" id="loginPassword" name="loginPassword" class="form-control" value="" placeholder="ADGANGSKODE" autocomplete="off" required>
			<label for="loginPassword">ADGANGSKODE</label>
		</div>
		<input id="login" class="button expanded color-bg-primary" type="submit" name="btnLogin" value="&rarr;">
 	</form>
	<button class="close-button" data-close aria-label="Close modal" type="button">
	<span aria-hidden="true">&times;</span>
	</button>
</div>