<?php
$cw = get_sub_field('sr_cw');
if ($cw) {
  $w = get_sub_field('sr_w');
  $wc = new WrapperClass($w, ''); 
}
$p = new ProductsClass();

$sc = new SearchClass();
$products = (isset($_GET['title']) || isset($_GET['category']) || isset($_GET['club'])) ? $sc->search() : '';

// echo '<pre>';
// print_r($p->products());
?>
<div class="sr-area <?= ($cw) ? $wc->marginPadding() : ''?>" <?= ($cw) ? $wc->wrapperStyle() : '' ?>>
	<div class="grid-container <?= ($cw) ? $wc->wrapperSize() : '' ?>">
		<div id="s-result" class="grid-x grid-padding-x small-up-2 medium-up-3 large-up-3 align-center">
			<?php if(isset($_GET['title']) || isset($_GET['category']) || isset($_GET['club'])) { ?>
			<?php
			$delay = 150; 
			foreach ($products as $product) { 
				$thumb = (isset($product['files'][0]['file_path'])) ? 'http://api.bordingvista.com/' . $product['files'][0]['file_path'] : get_template_directory_uri() . '/dist/assets/images/products/p1.jpg';
			?>
			<div class="cell wow slideInUp high-bottom-margin" data-wow-delay="<?= $delay ?>ms">
				<div class="drop-shadow lazy cover tg-bg-image" style="background-image: url(<?= $thumb ?>"></div>
				<div class="p-info clearfix">
					<a href="<?= site_url() ?>/product/<?= $product['sku'] ?>" class="p-name font-condensed font-18 float-left color-text-darkgray"><?= $product['title'] ?></a>
					<a href="<?= site_url() ?>/product/<?= $product['sku'] ?>" class="p-price font-condensed font-15 float-right text-center color-bg-primary color-text-white"><?= $product['initial_point'] ?> <br/>POINTS</a>
				</div>
				<a href="<?= site_url() ?>/product/<?= $product['sku'] ?>" class="p-link font-condensed font-18 color-text-gray">&rarr; <u>LÆS MERE</u></a><hr/>
			</div>
			<?php $delay += 50;
		}
			} else {
			$delay = (int)150; 
			foreach ($p->products() as $product) { 
				$thumb = (isset($product['files'][0]['file_path'])) ? 'http://api.bordingvista.com/' . $product['files'][0]['file_path'] : get_template_directory_uri() . '/dist/assets/images/products/p1.jpg';
			?>
			<div class="cell wow slideInUp high-bottom-margin" data-wow-delay="<?= $delay ?>ms">
				<div class="drop-shadow lazy cover tg-bg-image" style="background-image: url(<?= $thumb ?>"></div>
				<div class="p-info clearfix">
					<a href="<?= site_url() ?>/product/<?= $product['sku'] ?>" class="p-name font-condensed font-18 float-left color-text-darkgray"><?= $product['title'] ?></a>
					<a href="<?= site_url() ?>/product/<?= $product['sku'] ?>" class="p-price font-condensed font-15 float-right text-center color-bg-primary color-text-white"><?= $product['initial_point'] ?> <br/>POINTS</a>
				</div>
				<a href="<?= site_url() ?>/product/<?= $product['sku'] ?>" class="p-link font-condensed font-18 color-text-gray">&rarr; <u>LÆS MERE</u></a><hr/>
			</div>
			<?php $delay += 50;
		} 
	} ?>
		</div>
	</div>
</div>