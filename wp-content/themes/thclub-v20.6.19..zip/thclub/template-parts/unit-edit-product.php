<?php
	$p = new SingleProductAPIClass($_SESSION['clubKey'], url_last_part());
	$sp = $p->singleProductFromAPI();
	$product_images = $sp->files;

	/*echo "<pre>";
	print_r($sp);
	exit;*/
	$c = new ClubClass($sp->club_id);
	$cp = $c->singleClub();
	
?>

<?php if ( isset($_POST['btnEditProduct']) ) { 
	if(isset($_FILES)){
		$file_product = [];
	   foreach($_FILES['product_img']['name'] as $key => $val){	
		 	$file_product[$key]['file_name'] = $val;
		 }
	   foreach($_FILES['product_img']['tmp_name'] as $key => $val){

		 	$filename  = $val;
		 	$handle    = fopen($filename, "r");
		 	$data      = fread($handle, filesize($filename));
		 	$file_product[$key]['file_path'] = base64_encode($data);
		 }

		 $_POST['product_image'] = $file_product;

		 /*echo "<pre>";
		 print_r($_POST['product_image']);
		 exit;*/
	}

	?>
<div class="grid-container">
	<div class="grid-x align-center">
		<div class="cell small-12 medium-9 large-9 text-center">
			<div class="callout success" data-closable>
				<?php
				$ep = new EditProductClass($_POST, $_SESSION['clubKey']);
				print_r($ep->editProduct());
				?>
				<button class="close-button" aria-label="Dismiss alert" type="button" data-close>
				<span aria-hidden="true">&times;</span>
				</button>
			</div>
		</div>
	</div>
</div>
<?php }	?>
<?php
$category = new CategoryClass();
$category = $category->category();

$club = new ClubClass('');
$club = $club->club(); 
?>
<form id="product" action="<?= site_url('edit-product/' . $sp->id ) ?>" method="post" enctype="multipart/form-data" autocomplete="off">
	<div class="page-title bottom-border extra-top-padding extra-bottom-padding">
		<div class="grid-container">
			<div class="cell text-center">
				<?php the_title('<h1 class="wow slideInUp font-35 font-headline case-upper line-height no-margin">', '</h1>'); ?>
			</div>
		</div>
		<div class="grid-container">
			<div class="grid-x align-center">
				<div class="cell small-12 medium-9 large-9 extra-top-margin">
					<div id="cc" class="grid-x grid-padding-x ">
						<div class="cell samll-12 medium-6 large-6">
							<h4 class="font-condensed color-text-darkgray font-18 no-margin small-bottom-margin">PRODUKT</h4>
							<select name="category" id="category-id" required="">
								<option disabled="" value="" selected="" hidden="">VÆLG KATEGORI</option>
								<?php foreach ($category as $key => $value) { ?>
									<?php if ($sp->category_id == $value['id']) { ?>
										<option value="<?= $value['id'] ?>" selected><?= $value['name'] ?></option>
									<?php } else { ?>
										<option value="<?= $value['id'] ?>"><?= $value['name'] ?></option>
									<?php } ?>
								<?php } ?>
							</select>
						</div>
						<div class="cell samll-12 medium-6 large-6">
							<h4 class="font-condensed color-text-darkgray font-18 no-margin small-bottom-margin">AFSENDER</h4>
							<select name="club" id="club-id" required="">
								<option disabled="" value="" selected="" hidden="">VÆLG FIRMA</option>
								<?php foreach ($club as $key => $value) { ?>
									<?php if ($sp->club_id == $value['id']) { ?>
										<option value="<?= $value['id'] ?>" selected><?= $value['name'] ?></option>
									<?php } else { ?>
										<option value="<?= $value['id'] ?>"><?= $value['name'] ?></option>
									<?php } ?>
								<?php } ?>
							</select>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="create-product extra-top-margin extra-bottom-margin">
		<div class="grid-container" data-equalizer data-equalize-on="medium" id="r-form">
			<div id="product-grid" class="grid-x grid-padding-x" method="post">
				<div class="cell small-12 medium-6 large-4">
					<div class="selling" data-equalizer-watch="r-form">
						<h4 class="font-condensed color-text-darkgray font-18 no-margin small-bottom-margin">UPLOAD BILLEDE</h4>
						<div class="form-label-group">
						<ul class="p-thumb">
							<?php foreach ($product_images as $key => $val) {	?>
							<li class="relative">
								<img src="http://api.bordingvista.com/<?= $val->file_path ?>" alt="<?= $sp->title ?>">
								<a class="trash absolute contain center-center top color-bg-white"></a>
							</li>
							<!-- <input type="hidden" name="existence_img[]" value="<?= $val->file_path ?>"> -->
							<?php } ?>
						</ul>
							<button id="up-logo" type="button" class="button hollow secondary expanded">VÆLG FIL</button>
							<input type="file" name="product_img[]" id="profile-btn" class="outline">
							<div id=filesContainer class="form-label-group"></div>
							<button id="addFile" class="button hollow secondary expanded bold"> + </button>
						</div>
						<div class="form-label-group">
							<input type="text" id="productProductTitle" name="productProductTitle" class="form-control" value="<?= isset($_POST['productProductTitle']) ? $_POST['productProductTitle'] : $sp->title ?>" placeholder="PRODUKT NAVN" autocomplete="off">
							<label for="productProductTitle">PRODUKT NAVN</label>
						</div>
						<div class="form-label-group">
							<input type="text" id="productLocation" name="productLocation" class="form-control" value="<?= isset($_POST['productLocation']) ? $_POST['productLocation'] : $sp->location ?>" placeholder="STED" >
							<label for="productLocation">STED</label>
						</div>
						<div class="form-label-group">
							<input type="text" id="productAddress" name="productAddress" class="form-control" value="<?= isset($_POST['productAddress']) ? $_POST['productAddress'] : $sp->address ?>" placeholder="ADRESSE">
							<label for="productAddress">ADRESSE</label>
						</div>
						<div class="grid-x grid-margin-x">
							<div class="cell small-12 medium-4 large-4">
								<div class="form-label-group">
									<input type="text" id="productPost" name="productPost" class="form-control" value="<?= isset($_POST['productPost']) ? $_POST['productPost'] : $sp->post_code ?>" placeholder="POST NR." autocomplete="off">
									<label for="productPost">POST NR.</label>
								</div>
							</div>
							<div class="cell small-12 medium-8 large-8"><div class="form-label-group">
								<input type="text" id="productCity" name="productCity" class="form-control" placeholder="BY" value="<?= isset($_POST['productCity']) ? $_POST['productCity'] : $sp->city ?>" autocomplete="off">
								<label for="productCity">BY</label>
							</div>
						</div>
					</div>
					<div class="form-label-group">
						<input type="text" id="productOrganizer" name="productOrganizer" class="form-control" value="<?= isset($_POST['productOrganizer']) ? $_POST['productOrganizer'] : $sp->organizer  ?>" placeholder="ARRANGØR">
						<label for="productOrganizer">ARRANGØR</label>
					</div>
					<h4 class="font-condensed color-text-darkgray font-18 no-margin small-bottom-margin">EVT. UDLØBSDATO</h4>
					<div class="form-label-group">
						<input type="date" id="productExpireDate" name="productExpireDate" class="form-control" placeholder="EVT. UDLØBSDATO" value="<?= isset($_POST['productExpireDate']) ? $_POST['productExpireDate'] : $sp->expire_date ?>"	autocomplete="off">
						<label for="productExpireDate">EVT. UDLØBSDATO</label>
					</div>
					<h4 class="font-condensed color-text-darkgray font-18 no-margin small-bottom-margin">ANTAL</h4>
					<div class="form-label-group">
						<input type="text" id="productQuantity" name="productQuantity" class="form-control" placeholder="STK." value="<?= isset($_POST['productQuantity']) ? $_POST['productQuantity'] : $sp->total_number ?>"	autocomplete="off">
						<label for="productQuantity">STK.</label>
					</div>
					<h4 class="font-condensed color-text-darkgray font-18 no-margin small-bottom-margin">ANGIV PRIS</h4>
					<div class="form-label-group">
						<select class="form-control form-control-lg" id="productPrice" name="productPrice">
							<option disabled="" value="" selected="" hidden="">VÆLG PRIS</option>
							<option value="500" <?= ($sp->initial_point == 500) ? 'selected' : '' ?>>500 POINTS</option>
							<option value="1000" <?= ($sp->initial_point == 1000) ? 'selected' : '' ?>>1000 POINTS</option>
							<option value="1500" <?= ($sp->initial_point == 1500) ? 'selected' : '' ?>>1500 POINTS</option>
							<option value="2000" <?= ($sp->initial_point == 2000) ? 'selected' : '' ?>>2000 POINTS</option>
							<option value="2500" <?= ($sp->initial_point == 2500) ? 'selected' : '' ?>>2500 POINTS</option>
						</select>
					</div>
				</div>
			</div>
			<div class="cell small-12 medium-6 large-4">
				<div class="upload-logo" data-equalizer-watch="r-form">
					<h4 class="font-condensed color-text-darkgray font-18 no-margin small-bottom-margin">BESKRIVENDE TEKST</h4>
					<div class="form-label-group">
						<textarea rows="29" cols="50" id="productDescription" name="productDescription" class="form-control" placeholder="BESKRIVENDE TEKST"><?= isset($_POST['productDescription']) ? $_POST['productDescription'] : $sp->description ?></textarea>
						<label class="form-check-label" for="productDescription">BESKRIVENDE TEKST</label>
					</div>
				</div>
			</div>
			<div class="cell small-12 medium-6 large-4">
				<div class="seller relative" data-equalizer-watch="r-form">
					<h4 class="font-condensed color-text-darkgray font-18 no-margin small-bottom-margin">SÆLGER</h4>
					<div class="form-label-group">
						<input type="text" id="productSellerName" name="productSellerName" class="form-control" value="<?= isset($_POST['productSellerName']) ? $_POST['productSellerName'] : $sp->seller_club ?>" placeholder="FIRMA" autocomplete="off">
						<label for="productSellerName">FIRMA</label>
					</div>
					<div class="form-label-group">
						<input type="text" id="productSellerAddress" name="productSellerAddress" class="form-control" value="<?= isset($_POST['productSellerAddress']) ? $_POST['productSellerAddress'] : $sp->seller_address ?>" placeholder="ADRESSE">
						<label for="productSellerAddress">ADRESSE</label>
					</div>
					<div class="grid-x grid-margin-x">
						<div class="cell small-12 medium-4 large-4">
							<div class="form-label-group">
								<input type="text" id="productSellerPost" name="productSellerPost" class="form-control" value="<?= isset($_POST['productSellerPost']) ? $_POST['productSellerPost'] : $sp->seller_postcode ?>" placeholder="POST NR." autocomplete="off">
								<label for="productSellerPost">POST NR.</label>
							</div>
						</div>
						<div class="cell small-12 medium-8 large-8"><div class="form-label-group">
							<input type="text" id="productSellerCity" name="productSellerCity" class="form-control" placeholder="BY" value="<?= isset($_POST['productSellerCity']) ? $_POST['productSellerCity'] : $sp->seller_city  ?>" autocomplete="off">
							<label for="productSellerCity">BY</label>
						</div>
					</div>
				</div>
				<div class="form-label-group">
					<input type="email" id="productSellerEmail" name="productSellerEmail" class="form-control" value="<?= isset($_POST['productSellerEmail']) ? $_POST['productSellerEmail'] : $sp->seller_email ?>" placeholder="Email">
					<label for="productSellerEmail">Email</label>
				</div>
				<div class="form-label-group">
					<input type="text" id="productSellerTelephone" name="productSellerTelephone" class="form-control" value="<?= isset($_POST['productSellerTelephone']) ? $_POST['productSellerTelephone'] : $sp->seller_telephone ?>" placeholder="TLF NR.">
					<label for="productSellerTelephone">TLF NR.</label>
				</div>
				<div class="form-label-group">
					<textarea rows="12" cols="50" id="productSellerDescription" name="productSellerDescription" class="form-control" placeholder="SÆLGER BESKRIVELSE"><?= isset($_POST['productSellerDescription']) ? $_POST['productSellerDescription'] : $sp->seller_description ?></textarea>
					<label class="form-check-label" for="productSellerDescription">SÆLGER BESKRIVELSE</label>
				</div>
				<input type="hidden" name="p_e_id" value="<?= $sp->id ?>">
				<input id="create" class="absolute bottom no-margin font-18 font-condensed button expanded color-bg-primary" type="submit" name="btnEditProduct" value="REDIGERE">
			</div>
		</div>
	</div>
</div>
</div>
</form>