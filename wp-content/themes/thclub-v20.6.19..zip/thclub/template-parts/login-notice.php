<div class="cell text-center color-text-primary wow pulse" data-wow-iteration="3" data-wow-delay="1s">
<?php
if ( isset($_POST['btnLogin']) ) {
	$l = new LoginClass($_POST);
	$r = $l->login();
	if (isset($r->status)) {
		if ($r->status == 'success') {
			$_SESSION['clubKey'] = $r->result;
			wp_redirect(get_the_permalink());
			exit;
		} 
	} else {
		print_r($r);
	}
}
?>
</div>