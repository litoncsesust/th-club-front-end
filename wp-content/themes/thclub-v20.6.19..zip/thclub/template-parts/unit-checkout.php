<?php if ( isset($_POST['btnCheckout']) ) { ?>
<div class="grid-container">
	<div class="grid-x align-center">
		<div class="cell small-12 medium-9 large-9 text-center">
			<div class="callout success" data-closable>
				<?php
          $total_point = $_POST['total_point'];
          $total_quantity = $_POST['total_quantity'];
          unset($_POST['total_point']);
          unset($_POST['total_quantity']);
          unset($_POST['btnCheckout']);
          $data_arr['data_sku'] = $_POST;
          $data_arr['total_point'] = $total_point;
          $data_arr['total_quantity'] = $total_quantity;
					$cart_checkout = new CheckoutClass($data_arr);
					$return_response = $cart_checkout->checkout();
					
				?>
				<button class="close-button" aria-label="Dismiss alert" type="button" data-close>
				<span aria-hidden="true">&times;</span>
				</button>
			</div>
		</div>
	</div>
</div>
<?php }	?>
<div class="cart-area extra-top-margin extra-bottom-margin">
  <div class="grid-container">
    <div class="grid-x align-center">
      <div class="cell small-12 medium-9 large-9">
        <form method="POST" action="<?= site_url('/checkout') ?>">
            <table class="cart table hover table-bordered table-striped">
            <thead class="case-upper top-border bottom-border">
              <th class="normal font-condensed color-text-darkgray font-18">Produktdetaljer</th>
              <th class="normal font-condensed color-text-darkgray font-18">Punkt</th>
              <th class="normal font-condensed color-text-darkgray font-18 text-center">Antal</th>
              <th class="normal font-condensed color-text-darkgray font-18 text-right">Subtotal</th>
            </thead>
            <tbody>
              <?php
              //initialize total
              $total = 0;
              $total_quantity = 0;
              if(!empty($_SESSION['cart'])){
              //create array of initail qty which is 1
              $index = 0;
              if(!isset($_SESSION['qty_array'])){
              $_SESSION['qty_array'] = array_fill(0, count($_SESSION['cart']), 1);
              }
              foreach ($_SESSION['cart'] as $key => $val) {
              $p = new SingleProductClass($val);
              $sp = $p->singleProduct();
              ?>
              <tr>
                <td class="font-14" width="50%"><?= $sp['title'] ?></td>
                <td class="font-14" width="10%">
                <?= number_format($sp['initial_point'], 2); ?>
                <input type="hidden" name="<?= $sp['sku'] ?>" value="<?= $_SESSION['qty_array'][$index]; ?>">
                </td>
                <td class="font-14 text-center" width="15%"><?= $_SESSION['qty_array'][$index]; ?></td>
                <td class="font-14 text-right" width="15%">
                  <?= number_format($_SESSION['qty_array'][$index]*$sp['initial_point'], 2); ?>
                </td>
                <?php $total += $_SESSION['qty_array'][$index]*$sp['initial_point']; ?>
                <?php $total_quantity += $_SESSION['qty_array'][$index]; ?>
              </tr>
              <?php
              $index ++;
              }
              }
              else{
              ?>
              <tr><td colspan="4" class="text-center">No Item in Cart</td></tr>
              <?php
              }
              ?>
              <tr>
                <td class="text-left">
                  <a class="normal font-condensed case-upper button no-margin" href="<?= site_url() ?>">Fortsætte med at handle</a>
                </td>

                <td colspan="2" align="right" class="normal case-upper font-condensed color-text-darkgray font-20 text-left">Samlede point</td>
                <td class="normal case-upper font-condensed color-text-darkgray font-20 text-right"><?= number_format($total, 2); ?><input type="hidden" name="total_point" value="<?= $total ?>"><input type="hidden" name="total_quantity" value="<?= $total_quantity ?>"></td>
               </tr>
            </tbody>
          </table>
          <div class="cart-total large-top-margin">
            <h4 class="top-border bottom-border font-condensed font-18 no-margin small-bottom-margin">Dit nuværende punkt: <span class="font-condensed color-text-primary"><?= $_SESSION['clubKey']->point ?></span></h4>
            <h4 class="bottom-border font-condensed font-18 no-margin small-bottom-margin">Når du har gennemført dette køb, er dit resterende punkt: <span class="font-condensed color-text-primary"><?= ($_SESSION['clubKey']->point - $total)?></span></h4>
            <button type="submit" class="high-top-margin button normal case-upper font-condensed font-18 expanded color-bg-primary" name="btnCheckout">Indsend</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>