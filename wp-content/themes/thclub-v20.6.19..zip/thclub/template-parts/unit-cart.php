<?php
$choices = isset($_GET['cart']) ? $_GET['cart'] : '';
$c = new CartClass($choices);
$c->cart();
?>
<?php if(isset($_SESSION['message'])) { ?>
<div class="grid-container">
  <div class="grid-x align-center">
    <div class="cell small-12 medium-9 large-9 text-center">
      <div class="callout success" data-closable>
        <div class="alert alert-info text-center">
          <?= $_SESSION['message']; ?>
        </div>
        <button class="close-button" aria-label="Dismiss alert" type="button" data-close>
        <span aria-hidden="true">&times;</span>
        </button>
      </div>
    </div>
  </div>
</div>
<?php unset($_SESSION['message']); } ?>
<div class="cart-area extra-top-margin extra-bottom-margin">
  <div class="grid-container">
    <div class="grid-x align-center">
      <div class="cell small-12 medium-9 large-9">
        <form method="POST" action="<?= site_url('cart?cart=save') ?>">
          <table class="cart table hover table-bordered table-striped">
            <thead class="case-upper top-border bottom-border">
              <th></th>
              <th class="normal font-condensed color-text-darkgray font-18">Produktdetaljer</th>
              <th class="normal font-condensed color-text-darkgray font-18">Punkt</th>
              <th class="normal font-condensed color-text-darkgray font-18 text-center">Antal</th>
              <th class="normal font-condensed color-text-darkgray font-18 text-right">Subtotal</th>
            </thead>
            <tbody>
              <?php
              //initialize total
              $total = 0;
              if(!empty($_SESSION['cart'])) {
                //create array of initail qty which is 1               
                $index = 0;
                if(!isset($_SESSION['qty_array'])){
                  $_SESSION['qty_array'] = array_fill(0, count($_SESSION['cart']), 1);
                }

                foreach ($_SESSION['cart'] as $key => $val) {
                  $p = new SingleProductClass($val);
                  $sp = $p->singleProduct();
                  ?>
                  <tr>
                    <td width="10%">
                      <a class="trash contain center-center" href="<?= site_url('cart?cart=delete') ?>&id=<?= $sp['id'] ?>&index=<?= $index ?>">&nbsp;</a>
                    </td>
                    <td class="font-14" width="50%">
                      <?= $sp['title'] ?>
                    </td>
                    <td class="font-14" width="10%">
                    <?= number_format($sp['initial_point'], 2); ?>
                    <input type="hidden" name="indexes[]" value="<?= $index ?>">
                    </td>
                    <td width="15%">
                      <input type="number" min="1" class="font-14 form-control no-margin" value="<?= $_SESSION['qty_array'][$index]; ?>" name="qty_<?= $index ?>">
                    </td>
                    <td width="15%" class="font-14 text-right">
                      <?php echo number_format($_SESSION['qty_array'][$index]*$sp['initial_point'], 2); ?>
                    </td>
                    <?php $total += $_SESSION['qty_array'][$index]*$sp['initial_point']; ?>
                  </tr>
                <?php
                  $index ++;
                }
              } else {
              ?>
              <tr><td colspan="5" class="text-center">Ingen vare i kurv</td></tr>
              <?php
              }
              ?>
              <tr>
                <td colspan="3" class="text-left">
                  <a class="normal font-condensed case-upper button no-margin" href="<?= site_url() ?>">Fortsætte med at handle</a>
                <?php if(!empty($_SESSION['cart'])) { ?>
                  <a class="normal font-condensed case-upper alert button color-text-white no-margin" href="<?= site_url('cart?cart=clear') ?>">Klar vogn</a>
                <?php } ?>
                </td>
                <td colspan="2" class="text-right">
                <?php if(!empty($_SESSION['cart'])) { ?>
                  <button type="submit" class="normal success font-condensed color-text-white button no-margin" name="save">Opdater indkøbsvogn</button>
                <?php } ?>
                </td>
              </tr>
            </tbody>
          </table>
          <?php if(!empty($_SESSION['cart'])) { ?>
          <div class="cart-total large-top-margin">
            <h4 class="top-border bottom-border font-condensed color-text-darkgray font-25 no-margin small-bottom-margin">CART TOTAL</h4>
            <table class="cart table hover table-bordered table-striped">
              <tbody>
                <tr>
                  <td class="normal case-upper font-condensed color-text-darkgray font-20 text-left">Samlede point</td>
                  <td class="normal case-upper font-condensed color-text-darkgray font-20 text-right"><?= number_format($total, 2); ?></td>
                </tr>
              </tbody>
            </table>
            <?php if(!empty($_SESSION['clubKey'])) { ?>
              <?php if ($total > $_SESSION['clubKey']->point) { ?>
                <h4 class="top-border bottom-border font-condensed color-text-primary font-25 no-margin small-bottom-margin">Du samlede point: <?= $_SESSION['clubKey']->point ?><br/>Du har ikke tilstrækkelig balance</h4>
              <?php } else {?>
                <a id="cart" class="button normal case-upper font-condensed font-18 expanded color-bg-primary" href="<?= site_url('checkout') ?>">Gå til kassen &rarr;</a>
              <?php } ?>
            <?php } else { ?>
              <a class="button normal case-upper font-condensed font-18 expanded color-bg-primary" data-open="loginForm" aria-controls="loginForm" aria-haspopup="true" tabindex="0">Log ind</a>
            <?php } ?>
          </div>
          <?php } ?>
        </form>
      </div>
    </div>
  </div>
</div>
<script>
  window.history.replaceState({}, document.title, "/" + "dev.th-club.com/cart");
</script>