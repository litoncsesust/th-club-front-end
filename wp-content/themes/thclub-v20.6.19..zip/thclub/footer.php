<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the "off-canvas-wrap" div and all content after.
 *
 * @package fiftytwo
 * @since fiftytwo 1.0.0
 */
?>
<footer class="color-bg-lightblack medium-top-padding medium-bottom-padding">
	<div class="footer-container">
		<div class="bold color-text-gray case-upper text-center">
			<?php dynamic_sidebar( 'footer-widgets' ); ?>
		</div>
	</div>
</footer>

<?php if (!is_user_logged_in()) : ?>
<?php	get_template_part('template-parts/unit', 'login'); ?>
<?php endif; ?>

<?php if ( get_theme_mod( 'wpt_mobile_menu_layout' ) === 'offcanvas' ) : ?>
	</div><!-- Close off-canvas content -->
<?php endif; ?>
<?php wp_footer(); ?>
</body>
</html>