<?php
/**
 * Author: Ole Fredrik Lie
 * URL: http://olefredrik.com
 *
 * fiftytwo functions and definitions
 *
 * Set up the theme and provides some helper functions, which are used in the
 * theme as custom template tags. Others are attached to action and filter
 * hooks in WordPress to change core functionality.
 *
 * @link https://codex.wordpress.org/Theme_Development
 * @package fiftytwo
 * @since fiftytwo 1.0.0
 */

/** Various clean up functions */
require_once( 'library/login.php' );
require_once( 'library/login-nav.php' );
require_once( 'library/cleanup.php' );
require_once( 'library/foundation.php' );
require_once( 'library/class-fiftytwo-comments.php' );
require_once( 'library/navigation.php' );
require_once( 'library/class-fiftytwo-top-bar-walker.php' );
require_once( 'library/class-fiftytwo-mobile-walker.php' );
require_once( 'library/widget-areas.php' );
require_once( 'library/entry-meta.php' );
require_once( 'library/enqueue-scripts.php' );
require_once( 'library/theme-support.php' );
require_once( 'library/custom-nav.php' );
require_once( 'library/sticky-posts.php' );
require_once( 'library/responsive-images.php' );
require_once( 'library/gutenberg.php' );

require_once('library/session.php');

require_once('library/class-ButtonClass.php');
require_once('library/class-PhotoClass.php');
require_once('library/class-TypographyClass.php');
require_once('library/class-WrapperClass.php');
require_once('library/class-SelectClass.php');

require_once('library/api/club_api.php');

require_once('library/api/v3/base/index.php');
require_once('library/api/v3/data/index.php');
require_once('library/api/v3/register/index.php');
require_once('library/api/v3/create-product/index.php');
require_once('library/api/v3/edit-product/index.php');
require_once('library/api/v3/login/index.php');
require_once('library/api/v3/user/index.php');
require_once('library/api/v3/profile/index.php');
require_once('library/api/v3/products/index.php');
require_once('library/api/v3/club/index.php');
require_once('library/api/v3/club/store.php');
require_once('library/api/v3/category/index.php');
require_once('library/api/v3/category/store.php');

require_once('library/api/v3/single-product/index.php');
require_once('library/api/v3/single-product/single-from-api.php');

require_once('library/api/v3/user-products/index.php');
require_once('library/api/v3/search/index.php');
require_once('library/api/v3/params/index.php');

require_once('library/api/v3/cart/index.php');
require_once('library/api/v3/checkout/index.php');

//require_once('library/api/v3/club/index.php');
//require_once('library/api/v3/category/index.php');



/** If your site requires protocol relative url's for theme assets, uncomment the line below */
// require_once( 'library/class-fiftytwo-protocol-relative-theme-assets.php' );
